<?php
/**
 * Plugin Name: Sarzamin Aryan — County Featured Images Pack 05
 * Description: نصب و اتصال ۲۴ تصویر شاخص شهرستان‌ها: ادامه کرمانشاه، استان مرکزی، خراسان شمالی، فردوس و ترکمانچای. تصاویر WebP با اندازه ۱۲۰۰×۶۰۰ و زیر ۲۰۰KB.
 * Version: 1.0.0
 * Author: Sarzamin Aryan
 * Requires PHP: 8.1
 * Text Domain: sa-county-featured-images-pack-05
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
const SA_PACK05_CFI_VERSION = '1.0.0';
add_action( 'admin_menu', 'sa_pack05_cfi_register_tools_page', 99 );
add_action( 'admin_init', 'sa_pack05_cfi_maybe_run_from_admin' );
add_action( 'admin_notices', 'sa_pack05_cfi_admin_notices' );
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'sa_pack05_cfi_plugin_action_links' );
function sa_pack05_cfi_data() { return array(
		array( 'province' => 'kermanshah', 'slug' => 'sahneh', 'title' => 'شهرستان صحنه', 'province_name' => 'استان کرمانشاه', 'file' => 'images/kermanshah/sahneh.webp' ),
		array( 'province' => 'kermanshah', 'slug' => 'paveh', 'title' => 'شهرستان پاوه', 'province_name' => 'استان کرمانشاه', 'file' => 'images/kermanshah/paveh.webp' ),
		array( 'province' => 'kermanshah', 'slug' => 'gilan-e-gharb', 'title' => 'شهرستان گیلانغرب', 'province_name' => 'استان کرمانشاه', 'file' => 'images/kermanshah/gilan-e-gharb.webp' ),
		array( 'province' => 'kermanshah', 'slug' => 'ravansar', 'title' => 'شهرستان روانسر', 'province_name' => 'استان کرمانشاه', 'file' => 'images/kermanshah/ravansar.webp' ),
		array( 'province' => 'kermanshah', 'slug' => 'dalahu', 'title' => 'شهرستان دالاهو', 'province_name' => 'استان کرمانشاه', 'file' => 'images/kermanshah/dalahu.webp' ),
		array( 'province' => 'kermanshah', 'slug' => 'salas-e-babajani', 'title' => 'شهرستان ثلاث باباجانی', 'province_name' => 'استان کرمانشاه', 'file' => 'images/kermanshah/salas-e-babajani.webp' ),
		array( 'province' => 'kermanshah', 'slug' => 'qasr-e-shirin', 'title' => 'شهرستان قصر شیرین', 'province_name' => 'استان کرمانشاه', 'file' => 'images/kermanshah/qasr-e-shirin.webp' ),
		array( 'province' => 'markazi', 'slug' => 'arak', 'title' => 'شهرستان اراک', 'province_name' => 'استان مرکزی', 'file' => 'images/markazi/arak.webp' ),
		array( 'province' => 'markazi', 'slug' => 'saveh', 'title' => 'شهرستان ساوه', 'province_name' => 'استان مرکزی', 'file' => 'images/markazi/saveh.webp' ),
		array( 'province' => 'markazi', 'slug' => 'shazand', 'title' => 'شهرستان شازند', 'province_name' => 'استان مرکزی', 'file' => 'images/markazi/shazand.webp' ),
		array( 'province' => 'markazi', 'slug' => 'khomeyn', 'title' => 'شهرستان خمین', 'province_name' => 'استان مرکزی', 'file' => 'images/markazi/khomeyn.webp' ),
		array( 'province' => 'markazi', 'slug' => 'zarandieh', 'title' => 'شهرستان زرندیه', 'province_name' => 'استان مرکزی', 'file' => 'images/markazi/zarandieh.webp' ),
		array( 'province' => 'markazi', 'slug' => 'mahallat', 'title' => 'شهرستان محلات', 'province_name' => 'استان مرکزی', 'file' => 'images/markazi/mahallat.webp' ),
		array( 'province' => 'markazi', 'slug' => 'khondab', 'title' => 'شهرستان خنداب', 'province_name' => 'استان مرکزی', 'file' => 'images/markazi/khondab.webp' ),
		array( 'province' => 'markazi', 'slug' => 'delijan', 'title' => 'شهرستان دلیجان', 'province_name' => 'استان مرکزی', 'file' => 'images/markazi/delijan.webp' ),
		array( 'province' => 'markazi', 'slug' => 'komijan', 'title' => 'شهرستان کمیجان', 'province_name' => 'استان مرکزی', 'file' => 'images/markazi/komijan.webp' ),
		array( 'province' => 'markazi', 'slug' => 'farahan', 'title' => 'شهرستان فراهان', 'province_name' => 'استان مرکزی', 'file' => 'images/markazi/farahan.webp' ),
		array( 'province' => 'markazi', 'slug' => 'tafresh', 'title' => 'شهرستان تفرش', 'province_name' => 'استان مرکزی', 'file' => 'images/markazi/tafresh.webp' ),
		array( 'province' => 'markazi', 'slug' => 'ashtian', 'title' => 'شهرستان آشتیان', 'province_name' => 'استان مرکزی', 'file' => 'images/markazi/ashtian.webp' ),
		array( 'province' => 'north-khorasan', 'slug' => 'samalqan', 'title' => 'شهرستان سملقان', 'province_name' => 'استان خراسان شمالی', 'file' => 'images/north-khorasan/samalqan.webp' ),
		array( 'province' => 'north-khorasan', 'slug' => 'maneh', 'title' => 'شهرستان مانه', 'province_name' => 'استان خراسان شمالی', 'file' => 'images/north-khorasan/maneh.webp' ),
		array( 'province' => 'north-khorasan', 'slug' => 'bam-and-safiabad', 'title' => 'شهرستان بام و صفی‌آباد', 'province_name' => 'استان خراسان شمالی', 'file' => 'images/north-khorasan/bam-and-safiabad.webp' ),
		array( 'province' => 'south-khorasan', 'slug' => 'ferdows', 'title' => 'شهرستان فردوس', 'province_name' => 'استان خراسان جنوبی', 'file' => 'images/south-khorasan/ferdows.webp' ),
		array( 'province' => 'east-azerbaijan', 'slug' => 'torkamanchay', 'title' => 'شهرستان ترکمانچای', 'province_name' => 'استان آذربایجان شرقی', 'file' => 'images/east-azerbaijan/torkamanchay.webp' ),
	); }
function sa_pack05_cfi_register_tools_page() { add_management_page( 'نصب تصاویر شاخص شهرستان‌ها — بسته ۰۵', 'نصب تصاویر شاخص شهرستان‌ها — بسته ۰۵', 'manage_options', 'sa-county-featured-images-pack-05', 'sa_pack05_cfi_page' ); }
function sa_pack05_cfi_plugin_action_links( $links ) {
	$run_url = wp_nonce_url( add_query_arg( array( 'sa_pack05_cfi_run_now' => '1' ), admin_url( 'plugins.php' ) ), 'sa_pack05_cfi_import' );
	$page_url = add_query_arg( array( 'page' => 'sa-county-featured-images-pack-05' ), admin_url( 'tools.php' ) );
	array_unshift( $links, '<a href="' . esc_url( $run_url ) . '"><strong>' . esc_html__( 'اجرای نصب تصاویر', 'sa-county-featured-images-pack-05' ) . '</strong></a>' );
	$links[] = '<a href="' . esc_url( $page_url ) . '">' . esc_html__( 'صفحه نصب تصاویر', 'sa-county-featured-images-pack-05' ) . '</a>';
	return $links;
}
function sa_pack05_cfi_maybe_run_from_admin() {
	$run = filter_input( INPUT_GET, 'sa_pack05_cfi_run_now', FILTER_SANITIZE_NUMBER_INT );
	if ( ! $run ) { return; }
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( esc_html__( 'دسترسی کافی ندارید.', 'sa-county-featured-images-pack-05' ) ); }
	check_admin_referer( 'sa_pack05_cfi_import' );
	$result = sa_pack05_cfi_run();
	set_transient( 'sa_pack05_cfi_result_' . get_current_user_id(), $result, 10 * MINUTE_IN_SECONDS );
	wp_safe_redirect( add_query_arg( array( 'sa_pack05_cfi_done' => '1' ), admin_url( 'plugins.php' ) ) );
	exit;
}
function sa_pack05_cfi_admin_notices() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	$key = 'sa_pack05_cfi_result_' . get_current_user_id();
	$result = get_transient( $key );
	if ( ! is_array( $result ) ) { return; }
	delete_transient( $key );
	$class = empty( $result['errors'] ) ? 'notice notice-success is-dismissible' : 'notice notice-warning is-dismissible';
	echo '<div class="' . esc_attr( $class ) . '" dir="rtl"><p><strong>' . esc_html__( 'نتیجه نصب تصاویر شاخص:', 'sa-county-featured-images-pack-05' ) . '</strong> ' . esc_html( sprintf( 'آپلود جدید: %d، استفاده از قبلی: %d، اتصال به نوشته: %d، نوشته پیدا نشد: %d، خطا: %d', (int) $result['uploaded'], (int) $result['reused'], (int) $result['attached'], (int) $result['missing_posts'], (int) $result['errors'] ) ) . '</p>';
	if ( ! empty( $result['messages'] ) ) { echo '<details><summary>' . esc_html__( 'نمایش پیام‌ها', 'sa-county-featured-images-pack-05' ) . '</summary><ul style="list-style:disc;margin-right:2em;">'; foreach ( array_slice( (array) $result['messages'], 0, 100 ) as $message ) { echo '<li>' . esc_html( $message ) . '</li>'; } echo '</ul></details>'; }
	echo '</div>';
}
function sa_pack05_cfi_page() {
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( esc_html__( 'دسترسی کافی ندارید.', 'sa-county-featured-images-pack-05' ) ); }
	$result = null;
	$posted = filter_input( INPUT_POST, 'sa_pack05_cfi_import', FILTER_SANITIZE_NUMBER_INT );
	if ( $posted ) { check_admin_referer( 'sa_pack05_cfi_import' ); $result = sa_pack05_cfi_run(); }
	$run_url = wp_nonce_url( add_query_arg( array( 'sa_pack05_cfi_run_now' => '1' ), admin_url( 'plugins.php' ) ), 'sa_pack05_cfi_import' ); ?>
	<div class="wrap" dir="rtl"><h1>نصب تصاویر شاخص شهرستان‌ها — بسته ۰۵</h1><p>این بسته ۲۴ تصویر WebP را در رسانه وردپرس آپلود و به نوشته‌های city با نامک شهرستان وصل می‌کند: ۷ تصویر ادامه کرمانشاه، ۱۲ تصویر مرکزی، ۳ تصویر خراسان شمالی، فردوس و ترکمانچای.</p>
	<?php if ( is_array( $result ) ) : ?><div class="notice notice-success is-dismissible"><p><?php echo esc_html( sprintf( 'انجام شد: %d آپلود جدید، %d استفاده از تصویر قبلی، %d اتصال به نوشته، %d نوشته پیدا نشد، %d خطا.', $result['uploaded'], $result['reused'], $result['attached'], $result['missing_posts'], $result['errors'] ) ); ?></p></div><?php endif; ?>
	<form method="post" action="<?php echo esc_url( add_query_arg( 'page', 'sa-county-featured-images-pack-05', admin_url( 'tools.php' ) ) ); ?>"><?php wp_nonce_field( 'sa_pack05_cfi_import' ); ?><p><button type="submit" name="sa_pack05_cfi_import" value="1" class="button button-primary button-hero">آپلود و اتصال تصاویر شاخص</button></p></form>
	<p><a href="<?php echo esc_url( $run_url ); ?>" class="button button-secondary">اجرای نصب تصاویر از صفحه افزونه‌ها</a></p></div><?php
}
function sa_pack05_cfi_run() {
	$result = array( 'uploaded' => 0, 'reused' => 0, 'attached' => 0, 'missing_posts' => 0, 'errors' => 0, 'messages' => array() );
	if ( ! current_user_can( 'manage_options' ) ) { $result['errors']++; $result['messages'][] = 'دسترسی کافی نیست.'; return $result; }
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	foreach ( sa_pack05_cfi_data() as $item ) {
		$source = plugin_dir_path( __FILE__ ) . $item['file'];
		if ( ! is_readable( $source ) ) { $result['errors']++; $result['messages'][] = $item['title'] . ': فایل تصویر در افزونه پیدا نشد.'; continue; }
		$post_id = sa_pack05_cfi_find_post_by_slug( 'city', $item['slug'] );
		if ( ! $post_id ) { $result['missing_posts']++; }
		$key = $item['province'] . '/' . $item['slug'];
		$attachment_id = sa_pack05_cfi_find_attachment( $key );
		if ( $attachment_id ) { $result['reused']++; } else {
			$attachment_id = sa_pack05_cfi_upload_image( $source, $item, $post_id, $key );
			if ( is_wp_error( $attachment_id ) ) { $result['errors']++; $result['messages'][] = $item['title'] . ': ' . $attachment_id->get_error_message(); continue; }
			$result['uploaded']++;
		}
		if ( $post_id && $attachment_id ) {
			set_post_thumbnail( $post_id, $attachment_id );
			update_post_meta( $post_id, 'sa_featured_image_importer', 'sa-county-featured-images-pack-05-v' . SA_PACK05_CFI_VERSION );
			$result['attached']++;
			$result['messages'][] = $item['title'] . ': تصویر شاخص وصل شد.';
		} elseif ( ! $post_id && $attachment_id ) {
			$result['messages'][] = $item['title'] . ': تصویر آپلود شد، اما نوشته city با این نامک پیدا نشد.';
		}
	}
	update_option( 'sa_pack05_cfi_last_run', current_time( 'mysql' ), false );
	return $result;
}
function sa_pack05_cfi_find_post_by_slug( $post_type, $slug ) {
	$posts = get_posts( array( 'post_type' => $post_type, 'name' => sanitize_title( $slug ), 'post_status' => array( 'publish', 'draft', 'pending', 'future', 'private' ), 'posts_per_page' => 1, 'fields' => 'ids', 'no_found_rows' => true ) );
	return $posts ? (int) $posts[0] : 0;
}
function sa_pack05_cfi_find_attachment( $key ) {
	$posts = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'meta_key' => '_sa_county_featured_image_key', 'meta_value' => sanitize_text_field( $key ), 'posts_per_page' => 1, 'fields' => 'ids', 'no_found_rows' => true ) );
	return $posts ? (int) $posts[0] : 0;
}
function sa_pack05_cfi_upload_image( $source, $item, $post_id, $key ) {
	$upload = wp_upload_dir();
	if ( ! empty( $upload['error'] ) ) { return new WP_Error( 'upload_dir_error', $upload['error'] ); }
	$subdir = 'sarzaminaryan-county-featured/' . sanitize_key( $item['province'] );
	$target_dir = trailingslashit( $upload['basedir'] ) . $subdir;
	if ( ! wp_mkdir_p( $target_dir ) ) { return new WP_Error( 'mkdir_failed', 'ساخت پوشه آپلود ناموفق بود.' ); }
	$filename = sanitize_file_name( $item['slug'] . '-featured.webp' );
	$target = trailingslashit( $target_dir ) . $filename;
	if ( ! copy( $source, $target ) ) { return new WP_Error( 'copy_failed', 'کپی فایل تصویر ناموفق بود.' ); }
	$filetype = wp_check_filetype( $filename, null );
	$attachment = array( 'guid' => trailingslashit( $upload['baseurl'] ) . $subdir . '/' . $filename, 'post_mime_type' => $filetype['type'] ? $filetype['type'] : 'image/webp', 'post_title' => sanitize_text_field( $item['title'] . ' — تصویر شاخص' ), 'post_content' => '', 'post_status' => 'inherit', 'post_parent' => $post_id ? (int) $post_id : 0 );
	$attachment_id = wp_insert_attachment( wp_slash( $attachment ), $target, $post_id ? (int) $post_id : 0, true );
	if ( is_wp_error( $attachment_id ) ) { return $attachment_id; }
	$metadata = wp_generate_attachment_metadata( $attachment_id, $target );
	if ( is_array( $metadata ) ) { wp_update_attachment_metadata( $attachment_id, $metadata ); }
	update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( 'تصویر شاخص ' . $item['title'] . ' در ' . $item['province_name'] ) );
	update_post_meta( $attachment_id, '_sa_county_featured_image_key', sanitize_text_field( $key ) );
	update_post_meta( $attachment_id, '_sa_county_featured_image_size', '1200x600' );
	update_post_meta( $attachment_id, '_sa_county_featured_image_importer', 'sa-county-featured-images-pack-05-v' . SA_PACK05_CFI_VERSION );
	return (int) $attachment_id;
}
