<?php
/**
 * Plugin Name: Sarzamin Aryan — County Featured Images Pack 02
 * Description: نصب و اتصال ۳۰ تصویر شاخص دوم شهرستان‌های سرزمین آریان؛ ۲ تصویر پایانی همدان، یزد کامل، هرمزگان کامل، و ۳ تصویر اول گیلان. اجرای مستقیم از صفحه افزونه‌ها.
 * Version: 1.0.0
 * Author: Sarzamin Aryan
 * Requires PHP: 8.1
 * Text Domain: sa-county-featured-images-pack-02
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }
const SA_CFI_PACK_02_VERSION = '1.0.0';
add_action( 'admin_menu', 'sa_cfi_pack_02_register_tools_page', 99 );
add_action( 'admin_init', 'sa_cfi_pack_02_maybe_run_from_admin' );
add_action( 'admin_notices', 'sa_cfi_pack_02_admin_notices' );
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'sa_cfi_pack_02_plugin_action_links' );
function sa_cfi_pack_02_data() { return array(
		array( 'province' => 'hamadan', 'slug' => 'famenin', 'title' => 'شهرستان فامنین', 'province_name' => 'استان همدان', 'file' => 'images/hamadan/famenin.webp' ),
		array( 'province' => 'hamadan', 'slug' => 'dargazin', 'title' => 'شهرستان درگزین', 'province_name' => 'استان همدان', 'file' => 'images/hamadan/dargazin.webp' ),
		array( 'province' => 'yazd', 'slug' => 'yazd', 'title' => 'شهرستان یزد', 'province_name' => 'استان یزد', 'file' => 'images/yazd/yazd.webp' ),
		array( 'province' => 'yazd', 'slug' => 'meybod', 'title' => 'شهرستان میبد', 'province_name' => 'استان یزد', 'file' => 'images/yazd/meybod.webp' ),
		array( 'province' => 'yazd', 'slug' => 'ardakan', 'title' => 'شهرستان اردکان', 'province_name' => 'استان یزد', 'file' => 'images/yazd/ardakan.webp' ),
		array( 'province' => 'yazd', 'slug' => 'mehriz', 'title' => 'شهرستان مهریز', 'province_name' => 'استان یزد', 'file' => 'images/yazd/mehriz.webp' ),
		array( 'province' => 'yazd', 'slug' => 'abarkuh', 'title' => 'شهرستان ابرکوه', 'province_name' => 'استان یزد', 'file' => 'images/yazd/abarkuh.webp' ),
		array( 'province' => 'yazd', 'slug' => 'bafq', 'title' => 'شهرستان بافق', 'province_name' => 'استان یزد', 'file' => 'images/yazd/bafq.webp' ),
		array( 'province' => 'yazd', 'slug' => 'taft', 'title' => 'شهرستان تفت', 'province_name' => 'استان یزد', 'file' => 'images/yazd/taft.webp' ),
		array( 'province' => 'yazd', 'slug' => 'khatam', 'title' => 'شهرستان خاتم', 'province_name' => 'استان یزد', 'file' => 'images/yazd/khatam.webp' ),
		array( 'province' => 'yazd', 'slug' => 'ashkezar', 'title' => 'شهرستان اشکذر', 'province_name' => 'استان یزد', 'file' => 'images/yazd/ashkezar.webp' ),
		array( 'province' => 'yazd', 'slug' => 'behabad', 'title' => 'شهرستان بهاباد', 'province_name' => 'استان یزد', 'file' => 'images/yazd/behabad.webp' ),
		array( 'province' => 'yazd', 'slug' => 'zarach', 'title' => 'شهرستان زارچ', 'province_name' => 'استان یزد', 'file' => 'images/yazd/zarach.webp' ),
		array( 'province' => 'yazd', 'slug' => 'marvast', 'title' => 'شهرستان مروست', 'province_name' => 'استان یزد', 'file' => 'images/yazd/marvast.webp' ),
		array( 'province' => 'hormozgan', 'slug' => 'bandar-e-abbas', 'title' => 'شهرستان بندرعباس', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/bandar-e-abbas.webp' ),
		array( 'province' => 'hormozgan', 'slug' => 'bandar-lengeh', 'title' => 'شهرستان بندرلنگه', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/bandar-lengeh.webp' ),
		array( 'province' => 'hormozgan', 'slug' => 'minab', 'title' => 'شهرستان میناب', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/minab.webp' ),
		array( 'province' => 'hormozgan', 'slug' => 'qeshm', 'title' => 'شهرستان قشم', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/qeshm.webp' ),
		array( 'province' => 'hormozgan', 'slug' => 'abumusa', 'title' => 'شهرستان ابوموسی', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/abumusa.webp' ),
		array( 'province' => 'hormozgan', 'slug' => 'jask', 'title' => 'شهرستان جاسک', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/jask.webp' ),
		array( 'province' => 'hormozgan', 'slug' => 'rudan', 'title' => 'شهرستان رودان', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/rudan.webp' ),
		array( 'province' => 'hormozgan', 'slug' => 'hajjiabad', 'title' => 'شهرستان حاجی‌آباد', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/hajjiabad.webp' ),
		array( 'province' => 'hormozgan', 'slug' => 'bastak', 'title' => 'شهرستان بستک', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/bastak.webp' ),
		array( 'province' => 'hormozgan', 'slug' => 'parsian', 'title' => 'شهرستان پارسیان', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/parsian.webp' ),
		array( 'province' => 'hormozgan', 'slug' => 'khamir', 'title' => 'شهرستان خمیر', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/khamir.webp' ),
		array( 'province' => 'hormozgan', 'slug' => 'sirik', 'title' => 'شهرستان سیریک', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/sirik.webp' ),
		array( 'province' => 'hormozgan', 'slug' => 'bashagard', 'title' => 'شهرستان بشاگرد', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/bashagard.webp' ),
		array( 'province' => 'gilan', 'slug' => 'rasht', 'title' => 'شهرستان رشت', 'province_name' => 'استان گیلان', 'file' => 'images/gilan/rasht.webp' ),
		array( 'province' => 'gilan', 'slug' => 'talesh', 'title' => 'شهرستان تالش', 'province_name' => 'استان گیلان', 'file' => 'images/gilan/talesh.webp' ),
		array( 'province' => 'gilan', 'slug' => 'lahijan', 'title' => 'شهرستان لاهیجان', 'province_name' => 'استان گیلان', 'file' => 'images/gilan/lahijan.webp' ),
	); }
function sa_cfi_pack_02_register_tools_page() { add_management_page( 'نصب تصاویر شاخص شهرستان‌ها ۰۲', 'نصب تصاویر شاخص شهرستان‌ها ۰۲', 'manage_options', 'sa-county-featured-images-pack-02', 'sa_cfi_pack_02_page' ); }
function sa_cfi_pack_02_plugin_action_links( $links ) {
	$run_url  = wp_nonce_url( add_query_arg( array( 'sa_cfi_pack_02_run_now' => '1' ), admin_url( 'plugins.php' ) ), 'sa_cfi_pack_02_import' );
	$page_url = add_query_arg( array( 'page' => 'sa-county-featured-images-pack-02' ), admin_url( 'tools.php' ) );
	array_unshift( $links, '<a href="' . esc_url( $run_url ) . '"><strong>' . esc_html__( 'اجرای نصب تصاویر', 'sa-county-featured-images-pack-02' ) . '</strong></a>' );
	$links[] = '<a href="' . esc_url( $page_url ) . '">' . esc_html__( 'صفحه نصب تصاویر', 'sa-county-featured-images-pack-02' ) . '</a>';
	return $links;
}
function sa_cfi_pack_02_maybe_run_from_admin() {
	$run = filter_input( INPUT_GET, 'sa_cfi_pack_02_run_now', FILTER_SANITIZE_NUMBER_INT );
	if ( ! $run ) { return; }
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( esc_html__( 'دسترسی کافی ندارید.', 'sa-county-featured-images-pack-02' ) ); }
	check_admin_referer( 'sa_cfi_pack_02_import' );
	$result = sa_cfi_pack_02_run();
	set_transient( 'sa_cfi_pack_02_result_' . get_current_user_id(), $result, 10 * MINUTE_IN_SECONDS );
	wp_safe_redirect( add_query_arg( array( 'sa_cfi_pack_02_done' => '1' ), admin_url( 'plugins.php' ) ) ); exit;
}
function sa_cfi_pack_02_admin_notices() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	$key = 'sa_cfi_pack_02_result_' . get_current_user_id(); $result = get_transient( $key );
	if ( ! is_array( $result ) ) { return; } delete_transient( $key );
	$class = empty( $result['errors'] ) ? 'notice notice-success is-dismissible' : 'notice notice-warning is-dismissible';
	echo '<div class="' . esc_attr( $class ) . '" dir="rtl"><p><strong>' . esc_html__( 'نتیجه نصب تصاویر شاخص:', 'sa-county-featured-images-pack-02' ) . '</strong> ' . esc_html( sprintf( 'آپلود جدید: %d، استفاده از قبلی: %d، اتصال به نوشته: %d، نوشته پیدا نشد: %d، خطا: %d', (int) $result['uploaded'], (int) $result['reused'], (int) $result['attached'], (int) $result['missing_posts'], (int) $result['errors'] ) ) . '</p>';
	if ( ! empty( $result['messages'] ) ) { echo '<details><summary>' . esc_html__( 'نمایش پیام‌ها', 'sa-county-featured-images-pack-02' ) . '</summary><ul style="list-style:disc;margin-right:2em;">'; foreach ( array_slice( (array) $result['messages'], 0, 90 ) as $message ) { echo '<li>' . esc_html( $message ) . '</li>'; } echo '</ul></details>'; }
	echo '</div>';
}
function sa_cfi_pack_02_page() {
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( esc_html__( 'دسترسی کافی ندارید.', 'sa-county-featured-images-pack-02' ) ); }
	$result = null; $posted = filter_input( INPUT_POST, 'sa_cfi_pack_02_import', FILTER_SANITIZE_NUMBER_INT );
	if ( $posted ) { check_admin_referer( 'sa_cfi_pack_02_import' ); $result = sa_cfi_pack_02_run(); }
	$run_url = wp_nonce_url( add_query_arg( array( 'sa_cfi_pack_02_run_now' => '1' ), admin_url( 'plugins.php' ) ), 'sa_cfi_pack_02_import' ); ?>
	<div class="wrap" dir="rtl"><h1>نصب تصاویر شاخص شهرستان‌ها — بسته ۰۲</h1>
	<p>این افزونه ۳۰ تصویر WebP با اندازه ۱۲۰۰×۶۰۰ و حجم زیر ۲۰۰KB را در رسانه وردپرس آپلود می‌کند و به نوشته‌های <code>city</code> با نامک شهرستان وصل می‌کند.</p>
	<p><strong>محتوا:</strong> ۲ تصویر پایانی همدان، یزد کامل، هرمزگان کامل، و ۳ تصویر اول گیلان.</p>
	<?php if ( is_array( $result ) ) : ?><div class="notice notice-success is-dismissible"><p><?php echo esc_html( sprintf( 'انجام شد: %d آپلود جدید، %d استفاده از تصویر قبلی، %d اتصال به نوشته، %d نوشته پیدا نشد، %d خطا.', $result['uploaded'], $result['reused'], $result['attached'], $result['missing_posts'], $result['errors'] ) ); ?></p></div><?php endif; ?>
	<form method="post" action="<?php echo esc_url( add_query_arg( 'page', 'sa-county-featured-images-pack-02', admin_url( 'tools.php' ) ) ); ?>"><?php wp_nonce_field( 'sa_cfi_pack_02_import' ); ?><p><button type="submit" name="sa_cfi_pack_02_import" value="1" class="button button-primary button-hero">آپلود و اتصال ۳۰ تصویر شاخص</button></p></form>
	<p><a href="<?php echo esc_url( $run_url ); ?>" class="button button-secondary">اجرای نصب تصاویر از صفحه افزونه‌ها</a></p></div><?php
}
function sa_cfi_pack_02_run() {
	$result = array( 'uploaded' => 0, 'reused' => 0, 'attached' => 0, 'missing_posts' => 0, 'errors' => 0, 'messages' => array() );
	if ( ! current_user_can( 'manage_options' ) ) { $result['errors']++; $result['messages'][] = 'دسترسی کافی نیست.'; return $result; }
	require_once ABSPATH . 'wp-admin/includes/file.php'; require_once ABSPATH . 'wp-admin/includes/image.php';
	foreach ( sa_cfi_pack_02_data() as $item ) {
		$source = plugin_dir_path( __FILE__ ) . $item['file'];
		if ( ! is_readable( $source ) ) { $result['errors']++; $result['messages'][] = $item['title'] . ': فایل تصویر در افزونه پیدا نشد.'; continue; }
		$post_id = sa_cfi_pack_02_find_post_by_slug( 'city', $item['slug'] ); if ( ! $post_id ) { $result['missing_posts']++; }
		$key = $item['province'] . '/' . $item['slug']; $attachment_id = sa_cfi_pack_02_find_attachment( $key );
		if ( $attachment_id ) { $result['reused']++; } else { $attachment_id = sa_cfi_pack_02_upload_image( $source, $item, $post_id, $key ); if ( is_wp_error( $attachment_id ) ) { $result['errors']++; $result['messages'][] = $item['title'] . ': ' . $attachment_id->get_error_message(); continue; } $result['uploaded']++; }
		if ( $post_id && $attachment_id ) { set_post_thumbnail( $post_id, $attachment_id ); update_post_meta( $post_id, 'sa_featured_image_importer', 'pack-02-v' . SA_CFI_PACK_02_VERSION ); $result['attached']++; $result['messages'][] = $item['title'] . ': تصویر شاخص وصل شد.'; } elseif ( ! $post_id && $attachment_id ) { $result['messages'][] = $item['title'] . ': تصویر آپلود شد، اما نوشته city با این نامک پیدا نشد.'; }
	}
	update_option( 'sa_cfi_pack_02_last_run', current_time( 'mysql' ), false ); return $result;
}
function sa_cfi_pack_02_find_post_by_slug( $post_type, $slug ) { $posts = get_posts( array( 'post_type' => $post_type, 'name' => sanitize_title( $slug ), 'post_status' => array( 'publish', 'draft', 'pending', 'future', 'private' ), 'posts_per_page' => 1, 'fields' => 'ids', 'no_found_rows' => true ) ); return $posts ? (int) $posts[0] : 0; }
function sa_cfi_pack_02_find_attachment( $key ) { $posts = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'meta_key' => '_sa_county_featured_image_key', 'meta_value' => sanitize_text_field( $key ), 'posts_per_page' => 1, 'fields' => 'ids', 'no_found_rows' => true ) ); return $posts ? (int) $posts[0] : 0; }
function sa_cfi_pack_02_upload_image( $source, $item, $post_id, $key ) {
	$upload = wp_upload_dir(); if ( ! empty( $upload['error'] ) ) { return new WP_Error( 'upload_dir_error', $upload['error'] ); }
	$subdir = 'sarzaminaryan-county-featured/' . sanitize_key( $item['province'] ); $target_dir = trailingslashit( $upload['basedir'] ) . $subdir;
	if ( ! wp_mkdir_p( $target_dir ) ) { return new WP_Error( 'mkdir_failed', 'ساخت پوشه آپلود ناموفق بود.' ); }
	$filename = sanitize_file_name( $item['slug'] . '-featured.webp' ); $target = trailingslashit( $target_dir ) . $filename;
	if ( ! copy( $source, $target ) ) { return new WP_Error( 'copy_failed', 'کپی فایل تصویر ناموفق بود.' ); }
	$filetype = wp_check_filetype( $filename, null ); $attachment = array( 'guid' => trailingslashit( $upload['baseurl'] ) . $subdir . '/' . $filename, 'post_mime_type' => $filetype['type'] ? $filetype['type'] : 'image/webp', 'post_title' => sanitize_text_field( $item['title'] . ' — تصویر شاخص' ), 'post_content' => '', 'post_status' => 'inherit', 'post_parent' => $post_id ? (int) $post_id : 0 );
	$attachment_id = wp_insert_attachment( wp_slash( $attachment ), $target, $post_id ? (int) $post_id : 0, true ); if ( is_wp_error( $attachment_id ) ) { return $attachment_id; }
	$metadata = wp_generate_attachment_metadata( $attachment_id, $target ); if ( is_array( $metadata ) ) { wp_update_attachment_metadata( $attachment_id, $metadata ); }
	update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( 'تصویر شاخص ' . $item['title'] . ' در ' . $item['province_name'] ) ); update_post_meta( $attachment_id, '_sa_county_featured_image_key', sanitize_text_field( $key ) ); update_post_meta( $attachment_id, '_sa_county_featured_image_size', '1200x600' ); update_post_meta( $attachment_id, '_sa_county_featured_image_importer', 'pack-02-v' . SA_CFI_PACK_02_VERSION ); return (int) $attachment_id;
}
