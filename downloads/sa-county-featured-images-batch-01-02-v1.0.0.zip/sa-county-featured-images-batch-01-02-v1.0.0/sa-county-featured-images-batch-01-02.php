<?php
/**
 * Plugin Name: Sarzamin Aryan — County Featured Images Batch 01-02
 * Description: نصب و اتصال ۲۰ تصویر شاخص شهرستان‌های سرزمین آریان به نوشته‌های city؛ شامل چهارمحال و بختیاری کامل و ۸ تصویر اول کردستان. اجرای مستقیم از صفحه افزونه‌ها.
 * Version: 1.0.0
 * Author: Sarzamin Aryan
 * Requires PHP: 8.1
 * Text Domain: sa-county-featured-images-batch-01-02
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const SA_CFI_BATCH_0102_VERSION = '1.0.0';

add_action( 'admin_menu', 'sa_cfi_batch_0102_register_tools_page', 99 );
add_action( 'admin_init', 'sa_cfi_batch_0102_maybe_run_from_admin' );
add_action( 'admin_notices', 'sa_cfi_batch_0102_admin_notices' );
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'sa_cfi_batch_0102_plugin_action_links' );

function sa_cfi_batch_0102_data() {
	return array(
		array( 'province' => 'chaharmahal-bakhtiari', 'slug' => 'sharekurd', 'title' => 'شهرستان شهرکرد', 'province_name' => 'استان چهارمحال و بختیاری', 'file' => 'images/chaharmahal-bakhtiari/sharekurd.webp' ),
		array( 'province' => 'chaharmahal-bakhtiari', 'slug' => 'lordegan', 'title' => 'شهرستان لردگان', 'province_name' => 'استان چهارمحال و بختیاری', 'file' => 'images/chaharmahal-bakhtiari/lordegan.webp' ),
		array( 'province' => 'chaharmahal-bakhtiari', 'slug' => 'borujen', 'title' => 'شهرستان بروجن', 'province_name' => 'استان چهارمحال و بختیاری', 'file' => 'images/chaharmahal-bakhtiari/borujen.webp' ),
		array( 'province' => 'chaharmahal-bakhtiari', 'slug' => 'farsan', 'title' => 'شهرستان فارسان', 'province_name' => 'استان چهارمحال و بختیاری', 'file' => 'images/chaharmahal-bakhtiari/farsan.webp' ),
		array( 'province' => 'chaharmahal-bakhtiari', 'slug' => 'khanmirza', 'title' => 'شهرستان خانمیرزا', 'province_name' => 'استان چهارمحال و بختیاری', 'file' => 'images/chaharmahal-bakhtiari/khanmirza.webp' ),
		array( 'province' => 'chaharmahal-bakhtiari', 'slug' => 'kiar', 'title' => 'شهرستان کیار', 'province_name' => 'استان چهارمحال و بختیاری', 'file' => 'images/chaharmahal-bakhtiari/kiar.webp' ),
		array( 'province' => 'chaharmahal-bakhtiari', 'slug' => 'ardal', 'title' => 'شهرستان اردل', 'province_name' => 'استان چهارمحال و بختیاری', 'file' => 'images/chaharmahal-bakhtiari/ardal.webp' ),
		array( 'province' => 'chaharmahal-bakhtiari', 'slug' => 'kuhrang', 'title' => 'شهرستان کوهرنگ', 'province_name' => 'استان چهارمحال و بختیاری', 'file' => 'images/chaharmahal-bakhtiari/kuhrang.webp' ),
		array( 'province' => 'chaharmahal-bakhtiari', 'slug' => 'farrokhshahr', 'title' => 'شهرستان فرخ‌شهر', 'province_name' => 'استان چهارمحال و بختیاری', 'file' => 'images/chaharmahal-bakhtiari/farrokhshahr.webp' ),
		array( 'province' => 'chaharmahal-bakhtiari', 'slug' => 'saman', 'title' => 'شهرستان سامان', 'province_name' => 'استان چهارمحال و بختیاری', 'file' => 'images/chaharmahal-bakhtiari/saman.webp' ),
		array( 'province' => 'chaharmahal-bakhtiari', 'slug' => 'falard', 'title' => 'شهرستان فلارد', 'province_name' => 'استان چهارمحال و بختیاری', 'file' => 'images/chaharmahal-bakhtiari/falard.webp' ),
		array( 'province' => 'chaharmahal-bakhtiari', 'slug' => 'ben', 'title' => 'شهرستان بن', 'province_name' => 'استان چهارمحال و بختیاری', 'file' => 'images/chaharmahal-bakhtiari/ben.webp' ),
		array( 'province' => 'kurdistan', 'slug' => 'sanandaj', 'title' => 'شهرستان سنندج', 'province_name' => 'استان کردستان', 'file' => 'images/kurdistan/sanandaj.webp' ),
		array( 'province' => 'kurdistan', 'slug' => 'saqqez', 'title' => 'شهرستان سقز', 'province_name' => 'استان کردستان', 'file' => 'images/kurdistan/saqqez.webp' ),
		array( 'province' => 'kurdistan', 'slug' => 'marivan', 'title' => 'شهرستان مریوان', 'province_name' => 'استان کردستان', 'file' => 'images/kurdistan/marivan.webp' ),
		array( 'province' => 'kurdistan', 'slug' => 'baneh', 'title' => 'شهرستان بانه', 'province_name' => 'استان کردستان', 'file' => 'images/kurdistan/baneh.webp' ),
		array( 'province' => 'kurdistan', 'slug' => 'ghorveh', 'title' => 'شهرستان قروه', 'province_name' => 'استان کردستان', 'file' => 'images/kurdistan/ghorveh.webp' ),
		array( 'province' => 'kurdistan', 'slug' => 'kamyaran', 'title' => 'شهرستان کامیاران', 'province_name' => 'استان کردستان', 'file' => 'images/kurdistan/kamyaran.webp' ),
		array( 'province' => 'kurdistan', 'slug' => 'bijar', 'title' => 'شهرستان بیجار', 'province_name' => 'استان کردستان', 'file' => 'images/kurdistan/bijar.webp' ),
		array( 'province' => 'kurdistan', 'slug' => 'divandarreh', 'title' => 'شهرستان دیواندره', 'province_name' => 'استان کردستان', 'file' => 'images/kurdistan/divandarreh.webp' ),
	);
}

function sa_cfi_batch_0102_register_tools_page() {
	add_management_page( 'نصب تصاویر شاخص شهرستان‌ها', 'نصب تصاویر شاخص شهرستان‌ها', 'manage_options', 'sa-county-featured-images-batch-01-02', 'sa_cfi_batch_0102_page' );
}

function sa_cfi_batch_0102_plugin_action_links( $links ) {
	$run_url  = wp_nonce_url( add_query_arg( array( 'sa_cfi_batch_0102_run_now' => '1' ), admin_url( 'plugins.php' ) ), 'sa_cfi_batch_0102_import' );
	$page_url = add_query_arg( array( 'page' => 'sa-county-featured-images-batch-01-02' ), admin_url( 'tools.php' ) );
	array_unshift( $links, '<a href="' . esc_url( $run_url ) . '"><strong>' . esc_html__( 'اجرای نصب تصاویر', 'sa-county-featured-images-batch-01-02' ) . '</strong></a>' );
	$links[] = '<a href="' . esc_url( $page_url ) . '">' . esc_html__( 'صفحه نصب تصاویر', 'sa-county-featured-images-batch-01-02' ) . '</a>';
	return $links;
}

function sa_cfi_batch_0102_maybe_run_from_admin() {
	$run = filter_input( INPUT_GET, 'sa_cfi_batch_0102_run_now', FILTER_SANITIZE_NUMBER_INT );
	if ( ! $run ) {
		return;
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'دسترسی کافی ندارید.', 'sa-county-featured-images-batch-01-02' ) );
	}
	check_admin_referer( 'sa_cfi_batch_0102_import' );
	$result = sa_cfi_batch_0102_run();
	set_transient( 'sa_cfi_batch_0102_result_' . get_current_user_id(), $result, 10 * MINUTE_IN_SECONDS );
	wp_safe_redirect( add_query_arg( array( 'sa_cfi_batch_0102_done' => '1' ), admin_url( 'plugins.php' ) ) );
	exit;
}

function sa_cfi_batch_0102_admin_notices() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$key = 'sa_cfi_batch_0102_result_' . get_current_user_id();
	$result = get_transient( $key );
	if ( ! is_array( $result ) ) {
		return;
	}
	delete_transient( $key );
	$class = empty( $result['errors'] ) ? 'notice notice-success is-dismissible' : 'notice notice-warning is-dismissible';
	echo '<div class="' . esc_attr( $class ) . '" dir="rtl"><p><strong>' . esc_html__( 'نتیجه نصب تصاویر شاخص:', 'sa-county-featured-images-batch-01-02' ) . '</strong> ' . esc_html( sprintf( 'آپلود جدید: %d، استفاده از قبلی: %d، اتصال به نوشته: %d، نوشته پیدا نشد: %d، خطا: %d', (int) $result['uploaded'], (int) $result['reused'], (int) $result['attached'], (int) $result['missing_posts'], (int) $result['errors'] ) ) . '</p>';
	if ( ! empty( $result['messages'] ) ) {
		echo '<details><summary>' . esc_html__( 'نمایش پیام‌ها', 'sa-county-featured-images-batch-01-02' ) . '</summary><ul style="list-style:disc;margin-right:2em;">';
		foreach ( array_slice( (array) $result['messages'], 0, 60 ) as $message ) {
			echo '<li>' . esc_html( $message ) . '</li>';
		}
		echo '</ul></details>';
	}
	echo '</div>';
}

function sa_cfi_batch_0102_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'دسترسی کافی ندارید.', 'sa-county-featured-images-batch-01-02' ) );
	}
	$result = null;
	$posted = filter_input( INPUT_POST, 'sa_cfi_batch_0102_import', FILTER_SANITIZE_NUMBER_INT );
	if ( $posted ) {
		check_admin_referer( 'sa_cfi_batch_0102_import' );
		$result = sa_cfi_batch_0102_run();
	}
	$run_url = wp_nonce_url( add_query_arg( array( 'sa_cfi_batch_0102_run_now' => '1' ), admin_url( 'plugins.php' ) ), 'sa_cfi_batch_0102_import' );
	?>
	<div class="wrap" dir="rtl">
		<h1>نصب تصاویر شاخص شهرستان‌ها — بچ ۰۱-۰۲</h1>
		<p>این افزونه ۲۰ تصویر WebP با اندازه ۱۲۰۰×۶۰۰ و حجم زیر ۲۰۰KB را در رسانه وردپرس آپلود می‌کند و به نوشته‌های <code>city</code> با نامک شهرستان وصل می‌کند.</p>
		<p><strong>توجه:</strong> فایل‌های ZIP تصاویر خام افزونه نیستند. برای نصب در وردپرس، همین ZIP افزونه را نصب کنید.</p>
		<?php if ( is_array( $result ) ) : ?>
			<div class="notice notice-success is-dismissible"><p><?php echo esc_html( sprintf( 'انجام شد: %d آپلود جدید، %d استفاده از تصویر قبلی، %d اتصال به نوشته، %d نوشته پیدا نشد، %d خطا.', $result['uploaded'], $result['reused'], $result['attached'], $result['missing_posts'], $result['errors'] ) ); ?></p></div>
		<?php endif; ?>
		<form method="post" action="<?php echo esc_url( add_query_arg( 'page', 'sa-county-featured-images-batch-01-02', admin_url( 'tools.php' ) ) ); ?>">
			<?php wp_nonce_field( 'sa_cfi_batch_0102_import' ); ?>
			<p><button type="submit" name="sa_cfi_batch_0102_import" value="1" class="button button-primary button-hero">آپلود و اتصال تصاویر شاخص</button></p>
		</form>
		<p><a href="<?php echo esc_url( $run_url ); ?>" class="button button-secondary">اجرای نصب تصاویر از صفحه افزونه‌ها</a></p>
		<h2>فهرست تصاویر داخل افزونه</h2>
		<table class="widefat striped"><thead><tr><th>نامک</th><th>عنوان</th><th>استان</th><th>فایل</th></tr></thead><tbody>
		<?php foreach ( sa_cfi_batch_0102_data() as $item ) : ?>
			<tr><td dir="ltr"><code><?php echo esc_html( $item['slug'] ); ?></code></td><td><?php echo esc_html( $item['title'] ); ?></td><td><?php echo esc_html( $item['province_name'] ); ?></td><td dir="ltr"><code><?php echo esc_html( $item['file'] ); ?></code></td></tr>
		<?php endforeach; ?>
		</tbody></table>
	</div>
	<?php
}

function sa_cfi_batch_0102_run() {
	$result = array( 'uploaded' => 0, 'reused' => 0, 'attached' => 0, 'missing_posts' => 0, 'errors' => 0, 'messages' => array() );
	if ( ! current_user_can( 'manage_options' ) ) {
		$result['errors']++;
		$result['messages'][] = 'دسترسی کافی نیست.';
		return $result;
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	foreach ( sa_cfi_batch_0102_data() as $item ) {
		$source = plugin_dir_path( __FILE__ ) . $item['file'];
		if ( ! is_readable( $source ) ) {
			$result['errors']++;
			$result['messages'][] = $item['title'] . ': فایل تصویر در افزونه پیدا نشد.';
			continue;
		}
		$post_id = sa_cfi_batch_0102_find_post_by_slug( 'city', $item['slug'] );
		if ( ! $post_id ) {
			$result['missing_posts']++;
		}
		$key = $item['province'] . '/' . $item['slug'];
		$attachment_id = sa_cfi_batch_0102_find_attachment( $key );
		if ( $attachment_id ) {
			$result['reused']++;
		} else {
			$attachment_id = sa_cfi_batch_0102_upload_image( $source, $item, $post_id, $key );
			if ( is_wp_error( $attachment_id ) ) {
				$result['errors']++;
				$result['messages'][] = $item['title'] . ': ' . $attachment_id->get_error_message();
				continue;
			}
			$result['uploaded']++;
		}
		if ( $post_id && $attachment_id ) {
			set_post_thumbnail( $post_id, $attachment_id );
			update_post_meta( $post_id, 'sa_featured_image_importer', 'batch-01-02-v' . SA_CFI_BATCH_0102_VERSION );
			$result['attached']++;
			$result['messages'][] = $item['title'] . ': تصویر شاخص وصل شد.';
		} elseif ( ! $post_id && $attachment_id ) {
			$result['messages'][] = $item['title'] . ': تصویر آپلود شد، اما نوشته city با این نامک پیدا نشد.';
		}
	}
	update_option( 'sa_cfi_batch_0102_last_run', current_time( 'mysql' ), false );
	return $result;
}

function sa_cfi_batch_0102_find_post_by_slug( $post_type, $slug ) {
	$posts = get_posts( array( 'post_type' => $post_type, 'name' => sanitize_title( $slug ), 'post_status' => array( 'publish', 'draft', 'pending', 'future', 'private' ), 'posts_per_page' => 1, 'fields' => 'ids', 'no_found_rows' => true ) );
	return $posts ? (int) $posts[0] : 0;
}

function sa_cfi_batch_0102_find_attachment( $key ) {
	$posts = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'meta_key' => '_sa_county_featured_image_key', 'meta_value' => sanitize_text_field( $key ), 'posts_per_page' => 1, 'fields' => 'ids', 'no_found_rows' => true ) );
	return $posts ? (int) $posts[0] : 0;
}

function sa_cfi_batch_0102_upload_image( $source, $item, $post_id, $key ) {
	$upload = wp_upload_dir();
	if ( ! empty( $upload['error'] ) ) {
		return new WP_Error( 'upload_dir_error', $upload['error'] );
	}
	$subdir = 'sarzaminaryan-county-featured/' . sanitize_key( $item['province'] );
	$target_dir = trailingslashit( $upload['basedir'] ) . $subdir;
	if ( ! wp_mkdir_p( $target_dir ) ) {
		return new WP_Error( 'mkdir_failed', 'ساخت پوشه آپلود ناموفق بود.' );
	}
	$filename = sanitize_file_name( $item['slug'] . '-featured.webp' );
	$target = trailingslashit( $target_dir ) . $filename;
	if ( ! copy( $source, $target ) ) {
		return new WP_Error( 'copy_failed', 'کپی فایل تصویر ناموفق بود.' );
	}
	$filetype = wp_check_filetype( $filename, null );
	$attachment = array(
		'guid' => trailingslashit( $upload['baseurl'] ) . $subdir . '/' . $filename,
		'post_mime_type' => $filetype['type'] ? $filetype['type'] : 'image/webp',
		'post_title' => sanitize_text_field( $item['title'] . ' — تصویر شاخص' ),
		'post_content' => '',
		'post_status' => 'inherit',
		'post_parent' => $post_id ? (int) $post_id : 0,
	);
	$attachment_id = wp_insert_attachment( wp_slash( $attachment ), $target, $post_id ? (int) $post_id : 0, true );
	if ( is_wp_error( $attachment_id ) ) {
		return $attachment_id;
	}
	$metadata = wp_generate_attachment_metadata( $attachment_id, $target );
	if ( is_array( $metadata ) ) {
		wp_update_attachment_metadata( $attachment_id, $metadata );
	}
	update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( 'تصویر شاخص ' . $item['title'] . ' در ' . $item['province_name'] ) );
	update_post_meta( $attachment_id, '_sa_county_featured_image_key', sanitize_text_field( $key ) );
	update_post_meta( $attachment_id, '_sa_county_featured_image_size', '1200x600' );
	update_post_meta( $attachment_id, '_sa_county_featured_image_importer', 'batch-01-02-v' . SA_CFI_BATCH_0102_VERSION );
	return (int) $attachment_id;
}
