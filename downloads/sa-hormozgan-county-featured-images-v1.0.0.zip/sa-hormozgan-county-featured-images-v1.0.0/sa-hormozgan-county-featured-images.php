<?php
/**
 * Plugin Name: Sarzamin Aryan — Hormozgan County Featured Images
 * Description: نصب و اتصال ۱۳ تصویر شاخص شهرستان‌های استان هرمزگان. تصاویر WebP با اندازه ۱۲۰۰×۶۰۰ و زیر ۲۰۰KB. اجرای مستقیم از صفحه افزونه‌ها.
 * Version: 1.0.0
 * Author: Sarzamin Aryan
 * Requires PHP: 8.1
 * Text Domain: sa-hormozgan-county-featured-images
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const SA_HORMOZGAN_CFI_VERSION = '1.0.0';

add_action( 'admin_menu', 'sa_hormozgan_cfi_register_tools_page', 99 );
add_action( 'admin_init', 'sa_hormozgan_cfi_maybe_run_from_admin' );
add_action( 'admin_notices', 'sa_hormozgan_cfi_admin_notices' );
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'sa_hormozgan_cfi_plugin_action_links' );

function sa_hormozgan_cfi_data() {
	return array(
		array( 'province' => 'hormozgan', 'slug' => 'bandar-e-abbas', 'title' => 'شهرستان بندرعباس', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/bandar-e-abbas.webp' ),
		array( 'province' => 'hormozgan', 'slug' => 'bandar-lengeh', 'title' => 'شهرستان بندرلنگه', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/bandar-lengeh.webp' ),
		array( 'province' => 'hormozgan', 'slug' => 'minab', 'title' => 'شهرستان میناب', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/minab.webp' ),
		array( 'province' => 'hormozgan', 'slug' => 'qeshm', 'title' => 'شهرستان قشم', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/qeshm.webp' ),
		array( 'province' => 'hormozgan', 'slug' => 'abumusa', 'title' => 'شهرستان ابوموسی', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/abumusa.webp' ),
		array( 'province' => 'hormozgan', 'slug' => 'jask', 'title' => 'شهرستان جاسک', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/jask.webp' ),
		array( 'province' => 'hormozgan', 'slug' => 'rudan', 'title' => 'شهرستان رودان', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/rudan.webp' ),
		array( 'province' => 'hormozgan', 'slug' => 'hajjiabad', 'title' => 'شهرستان حاجی‌آباد', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/hajjiabad.webp' ),
		array( 'province' => 'hormozgan', 'slug' => 'bastak', 'title' => 'شهرستان بستک', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/bastak.webp' ),
		array( 'province' => 'hormozgan', 'slug' => 'parsian', 'title' => 'شهرستان پارسیان', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/parsian.webp' ),
		array( 'province' => 'hormozgan', 'slug' => 'khamir', 'title' => 'شهرستان خمیر', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/khamir.webp' ),
		array( 'province' => 'hormozgan', 'slug' => 'sirik', 'title' => 'شهرستان سیریک', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/sirik.webp' ),
		array( 'province' => 'hormozgan', 'slug' => 'bashagard', 'title' => 'شهرستان بشاگرد', 'province_name' => 'استان هرمزگان', 'file' => 'images/hormozgan/bashagard.webp' ),
	);
}

function sa_hormozgan_cfi_register_tools_page() {
	add_management_page( 'نصب تصاویر شاخص هرمزگان', 'نصب تصاویر شاخص هرمزگان', 'manage_options', 'sa-hormozgan-county-featured-images', 'sa_hormozgan_cfi_page' );
}

function sa_hormozgan_cfi_plugin_action_links( $links ) {
	$run_url  = wp_nonce_url( add_query_arg( array( 'sa_hormozgan_cfi_run_now' => '1' ), admin_url( 'plugins.php' ) ), 'sa_hormozgan_cfi_import' );
	$page_url = add_query_arg( array( 'page' => 'sa-hormozgan-county-featured-images' ), admin_url( 'tools.php' ) );
	array_unshift( $links, '<a href="' . esc_url( $run_url ) . '"><strong>' . esc_html__( 'اجرای نصب تصاویر', 'sa-hormozgan-county-featured-images' ) . '</strong></a>' );
	$links[] = '<a href="' . esc_url( $page_url ) . '">' . esc_html__( 'صفحه نصب تصاویر', 'sa-hormozgan-county-featured-images' ) . '</a>';
	return $links;
}

function sa_hormozgan_cfi_maybe_run_from_admin() {
	$run = filter_input( INPUT_GET, 'sa_hormozgan_cfi_run_now', FILTER_SANITIZE_NUMBER_INT );
	if ( ! $run ) { return; }
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( esc_html__( 'دسترسی کافی ندارید.', 'sa-hormozgan-county-featured-images' ) ); }
	check_admin_referer( 'sa_hormozgan_cfi_import' );
	$result = sa_hormozgan_cfi_run();
	set_transient( 'sa_hormozgan_cfi_result_' . get_current_user_id(), $result, 10 * MINUTE_IN_SECONDS );
	wp_safe_redirect( add_query_arg( array( 'sa_hormozgan_cfi_done' => '1' ), admin_url( 'plugins.php' ) ) );
	exit;
}

function sa_hormozgan_cfi_admin_notices() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	$key = 'sa_hormozgan_cfi_result_' . get_current_user_id();
	$result = get_transient( $key );
	if ( ! is_array( $result ) ) { return; }
	delete_transient( $key );
	$class = empty( $result['errors'] ) ? 'notice notice-success is-dismissible' : 'notice notice-warning is-dismissible';
	echo '<div class="' . esc_attr( $class ) . '" dir="rtl"><p><strong>' . esc_html__( 'نتیجه نصب تصاویر شاخص هرمزگان:', 'sa-hormozgan-county-featured-images' ) . '</strong> ' . esc_html( sprintf( 'آپلود جدید: %d، استفاده از قبلی: %d، اتصال به نوشته: %d، نوشته پیدا نشد: %d، خطا: %d', (int) $result['uploaded'], (int) $result['reused'], (int) $result['attached'], (int) $result['missing_posts'], (int) $result['errors'] ) ) . '</p>';
	if ( ! empty( $result['messages'] ) ) {
		echo '<details><summary>' . esc_html__( 'نمایش پیام‌ها', 'sa-hormozgan-county-featured-images' ) . '</summary><ul style="list-style:disc;margin-right:2em;">';
		foreach ( array_slice( (array) $result['messages'], 0, 60 ) as $message ) { echo '<li>' . esc_html( $message ) . '</li>'; }
		echo '</ul></details>';
	}
	echo '</div>';
}

function sa_hormozgan_cfi_page() {
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( esc_html__( 'دسترسی کافی ندارید.', 'sa-hormozgan-county-featured-images' ) ); }
	$result = null;
	$posted = filter_input( INPUT_POST, 'sa_hormozgan_cfi_import', FILTER_SANITIZE_NUMBER_INT );
	if ( $posted ) { check_admin_referer( 'sa_hormozgan_cfi_import' ); $result = sa_hormozgan_cfi_run(); }
	$run_url = wp_nonce_url( add_query_arg( array( 'sa_hormozgan_cfi_run_now' => '1' ), admin_url( 'plugins.php' ) ), 'sa_hormozgan_cfi_import' );
	?>
	<div class="wrap" dir="rtl">
		<h1>نصب تصاویر شاخص شهرستان‌های هرمزگان</h1>
		<p>این افزونه ۱۳ تصویر WebP استان هرمزگان را در رسانه وردپرس آپلود و به نوشته‌های <code>city</code> با نامک شهرستان وصل می‌کند.</p>
		<?php if ( is_array( $result ) ) : ?>
			<div class="notice notice-success is-dismissible"><p><?php echo esc_html( sprintf( 'انجام شد: %d آپلود جدید، %d استفاده از تصویر قبلی، %d اتصال به نوشته، %d نوشته پیدا نشد، %d خطا.', $result['uploaded'], $result['reused'], $result['attached'], $result['missing_posts'], $result['errors'] ) ); ?></p></div>
		<?php endif; ?>
		<form method="post" action="<?php echo esc_url( add_query_arg( 'page', 'sa-hormozgan-county-featured-images', admin_url( 'tools.php' ) ) ); ?>">
			<?php wp_nonce_field( 'sa_hormozgan_cfi_import' ); ?>
			<p><button type="submit" name="sa_hormozgan_cfi_import" value="1" class="button button-primary button-hero">آپلود و اتصال تصاویر شاخص هرمزگان</button></p>
		</form>
		<p><a href="<?php echo esc_url( $run_url ); ?>" class="button button-secondary">اجرای نصب تصاویر از صفحه افزونه‌ها</a></p>
	</div>
	<?php
}

function sa_hormozgan_cfi_run() {
	$result = array( 'uploaded' => 0, 'reused' => 0, 'attached' => 0, 'missing_posts' => 0, 'errors' => 0, 'messages' => array() );
	if ( ! current_user_can( 'manage_options' ) ) { $result['errors']++; $result['messages'][] = 'دسترسی کافی نیست.'; return $result; }
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	foreach ( sa_hormozgan_cfi_data() as $item ) {
		$source = plugin_dir_path( __FILE__ ) . $item['file'];
		if ( ! is_readable( $source ) ) { $result['errors']++; $result['messages'][] = $item['title'] . ': فایل تصویر در افزونه پیدا نشد.'; continue; }
		$post_id = sa_hormozgan_cfi_find_post_by_slug( 'city', $item['slug'] );
		if ( ! $post_id ) { $result['missing_posts']++; }
		$key = $item['province'] . '/' . $item['slug'];
		$attachment_id = sa_hormozgan_cfi_find_attachment( $key );
		if ( $attachment_id ) { $result['reused']++; } else {
			$attachment_id = sa_hormozgan_cfi_upload_image( $source, $item, $post_id, $key );
			if ( is_wp_error( $attachment_id ) ) { $result['errors']++; $result['messages'][] = $item['title'] . ': ' . $attachment_id->get_error_message(); continue; }
			$result['uploaded']++;
		}
		if ( $post_id && $attachment_id ) {
			set_post_thumbnail( $post_id, $attachment_id );
			update_post_meta( $post_id, 'sa_featured_image_importer', 'hormozgan-v' . SA_HORMOZGAN_CFI_VERSION );
			$result['attached']++;
			$result['messages'][] = $item['title'] . ': تصویر شاخص وصل شد.';
		} elseif ( ! $post_id && $attachment_id ) { $result['messages'][] = $item['title'] . ': تصویر آپلود شد، اما نوشته city با این نامک پیدا نشد.'; }
	}
	update_option( 'sa_hormozgan_cfi_last_run', current_time( 'mysql' ), false );
	return $result;
}

function sa_hormozgan_cfi_find_post_by_slug( $post_type, $slug ) {
	$posts = get_posts( array( 'post_type' => $post_type, 'name' => sanitize_title( $slug ), 'post_status' => array( 'publish', 'draft', 'pending', 'future', 'private' ), 'posts_per_page' => 1, 'fields' => 'ids', 'no_found_rows' => true ) );
	return $posts ? (int) $posts[0] : 0;
}
function sa_hormozgan_cfi_find_attachment( $key ) {
	$posts = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'meta_key' => '_sa_county_featured_image_key', 'meta_value' => sanitize_text_field( $key ), 'posts_per_page' => 1, 'fields' => 'ids', 'no_found_rows' => true ) );
	return $posts ? (int) $posts[0] : 0;
}
function sa_hormozgan_cfi_upload_image( $source, $item, $post_id, $key ) {
	$upload = wp_upload_dir();
	if ( ! empty( $upload['error'] ) ) { return new WP_Error( 'upload_dir_error', $upload['error'] ); }
	$subdir = 'sarzaminaryan-county-featured/' . sanitize_key( $item['province'] );
	$target_dir = trailingslashit( $upload['basedir'] ) . $subdir;
	if ( ! wp_mkdir_p( $target_dir ) ) { return new WP_Error( 'mkdir_failed', 'ساخت پوشه آپلود ناموفق بود.' ); }
	$filename = sanitize_file_name( $item['slug'] . '-featured.webp' );
	$target = trailingslashit( $target_dir ) . $filename;
	if ( ! copy( $source, $target ) ) { return new WP_Error( 'copy_failed', 'کپی فایل تصویر ناموفق بود.' ); }
	$filetype = wp_check_filetype( $filename, null );
	$attachment = array( 'guid' => trailingslashit( $upload['baseurl'] ) . $subdir . '/' . $filename, 'post_mime_type' => $filetype['type'] ? $filetype['type'] : 'image/webp', 'post_title' => sanitize_text_field( $item['title'] . ' — تصویر شاخص' ), 'post_content' => '', 'post_status' => 'inherit', 'post_parent' => $post_id ? (int) $post_id : 0 );
	$attachment_id = wp_insert_attachment( wp_slash( $attachment ), $target, $post_id ? (int) $post_id : 0, true );
	if ( is_wp_error( $attachment_id ) ) { return $attachment_id; }
	$metadata = wp_generate_attachment_metadata( $attachment_id, $target );
	if ( is_array( $metadata ) ) { wp_update_attachment_metadata( $attachment_id, $metadata ); }
	update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( 'تصویر شاخص ' . $item['title'] . ' در ' . $item['province_name'] ) );
	update_post_meta( $attachment_id, '_sa_county_featured_image_key', sanitize_text_field( $key ) );
	update_post_meta( $attachment_id, '_sa_county_featured_image_size', '1200x600' );
	update_post_meta( $attachment_id, '_sa_county_featured_image_importer', 'hormozgan-v' . SA_HORMOZGAN_CFI_VERSION );
	return (int) $attachment_id;
}
