<?php
/**
 * Level 7 publish gate — advisory by default (data model v1.3).
 *
 * Publishing policy (owner decision, 2026-10-11): the only condition for publishing
 * an entity is the owner's explicit approval (pressing «انتشار» or ticking «تأیید
 * مالک» in the ready-articles tool). Every Level 7 check — missing_relation,
 * missing_seo_fields, missing_featured_image, missing_primary_taxonomy,
 * missing_sources, content hygiene, FAQ/link counts, coordinates, uncertainty
 * markers and stale last_verified_date — is reported as a reminder (warning) but
 * never blocks or demotes a post.
 *
 * Mode (Customizer `sa_gate_mode`): 'soft' = publish + reminders (default since
 * v2.12.7), 'hard' = opt-in legacy behaviour that demotes an incomplete entity to
 * draft. Published pages are never demoted in either mode (v2.11.42).
 *
 * @package Sarzaminaryan_Child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Required belongs_to relations per type.
 *
 * @param string $type CPT.
 * @return string[] meta keys
 */
function sa_gate_required_relations( $type ) {
	switch ( $type ) {
		case 'city':
			return array( 'sa_province_id' );
		case 'attraction':
		case 'local_food':
		case 'souvenir':
		case 'accommodation':
			return array( 'sa_city_id' );
		case 'travel_route':
			return array( 'sa_city_ids' );
		default:
			return array();
	}
}

/**
 * Evaluate blockers for a post from either the submitted form or stored meta.
 *
 * @param int         $post_id Post ID (0 for new).
 * @param string      $type    CPT.
 * @param array|null  $form    $_POST-like array when saving via the edit screen, null to read meta.
 * @return string[] Human-readable list of missing items (empty = passes).
 */
function sa_gate_missing( $post_id, $type, $form = null ) {
	$e = sa_entity( $type );
	if ( ! $e ) {
		return array();
	}
	$missing = array();

	$get = function ( $key ) use ( $post_id, $form ) {
		if ( null !== $form ) {
			return isset( $form[ $key ] ) ? $form[ $key ] : '';
		}
		return get_post_meta( $post_id, $key, true );
	};

	// missing_relation.
	foreach ( sa_gate_required_relations( $type ) as $key ) {
		$val = $get( $key );
		if ( is_array( $val ) ) {
			$val = array_filter( array_map( 'absint', $val ) );
		}
		if ( 'sa_city_ids' === $key && null === $form ) {
			$val = sa_meta_ids( $post_id, $key );
		}
		if ( empty( $val ) ) {
			$target    = 'sa_city_ids' === $key ? 'شهرهای مسیر' : sa_entity_label( str_replace( array( 'sa_', '_id' ), '', $key ) );
			$missing[] = 'رابطه: ' . $target . ' انتخاب نشده است';
		}
	}

	// missing_seo_fields.
	foreach ( array( 'sa_seo_title' => 'عنوان سئو', 'sa_seo_description' => 'توضیحات متا', 'sa_focus_keyword' => 'کلیدواژه‌ی کانونی' ) as $key => $label ) {
		if ( '' === trim( (string) $get( $key ) ) ) {
			$missing[] = 'سئو: ' . $label;
		}
	}

	// FAQ is optional. The visible accordion is editorial content, not a publish requirement.
	$min = sa_content_minimums( $type );
	$content = null !== $form
		? ( isset( $form['post_content'] ) ? (string) $form['post_content'] : (string) get_post_field( 'post_content', $post_id ) )
		: (string) get_post_field( 'post_content', $post_id );

	// missing_featured_image.
	// v2.11.11: attraction/«دیدنی» pages use a generated white diagram card
	// instead of the old large featured-image model, so a thumbnail is optional.
	if ( 'attraction' !== $type ) {
		$thumb = null !== $form ? ( isset( $form['_thumbnail_id'] ) ? (int) $form['_thumbnail_id'] : 0 ) : (int) get_post_thumbnail_id( $post_id );
		if ( $thumb <= 0 ) {
			$missing[] = 'تصویر شاخص';
		}
	}

	// missing_primary_taxonomy.
	$tax = $e['primary_taxonomy'];
	if ( taxonomy_exists( $tax ) ) {
		$has_term = false;
		if ( null !== $form ) {
			$input = isset( $form['tax_input'][ $tax ] ) ? (array) $form['tax_input'][ $tax ] : array();
			$input = array_filter( array_map( 'trim', array_map( 'strval', $input ) ), 'strlen' );
			$input = array_diff( $input, array( '0' ) );
			$has_term = ! empty( $input );
			// province_tax is auto-assigned from the relation for non-province entities.
			if ( ! $has_term && 'province_tax' === $tax && 'province' !== $type ) {
				$has_term = ! empty( $form['sa_city_id'] ) || ! empty( $form['sa_province_id'] ) || ! empty( $form['sa_city_ids'] );
			}
		} else {
			$has_term = has_term( '', $tax, $post_id );
		}
		if ( ! $has_term ) {
			$missing[] = 'طبقه‌بندی اصلی: ' . sa_taxonomies_config()[ $tax ]['singular'];
		}
	}

	// v1.1 — missing_coordinates.
	if ( ! empty( $min['coordinates'] ) ) {
		$lat_key = $lng_key = '';
		foreach ( $e['fields'] as $f ) {
			if ( substr( $f['name'], -8 ) === 'latitude' ) {
				$lat_key = $f['key'];
			} elseif ( substr( $f['name'], -9 ) === 'longitude' ) {
				$lng_key = $f['key'];
			}
		}
		if ( $lat_key && ( '' === trim( (string) $get( $lat_key ) ) || '' === trim( (string) $get( $lng_key ) ) ) ) {
			$missing[] = 'مختصات جغرافیایی (عرض و طول)';
		}
	}

	// v1.1 — missing_sources.
	$src_min = (int) $min['sources'];
	if ( $src_min > 0 ) {
		$src_count = sa_count_sources( (string) $get( 'sa_sources' ) );
		if ( $src_count < $src_min ) {
			$missing[] = 'منابع: ' . sa_fa_digits( $src_count ) . ' از حداقل ' . sa_fa_digits( $src_min ) . ' منبع دارای لینک';
		}
	}

	// v1.2 — link volume is diagnostic only; sa_gate_split() keeps it advisory.
	$link_min = (int) $min['internal_links'];
	if ( $link_min > 0 ) {
		$links = sa_count_internal_links( $content );
		if ( $links < $link_min ) {
			$missing[] = 'لینک داخلی: ' . sa_fa_digits( $links ) . ' از هدف تحریریهٔ ' . sa_fa_digits( $link_min ) . ' لینک؛ فقط اگر برای خواننده مفید است اضافه کنید';
		}
	}

	// v1.2 — content hygiene is a hard blocker (distinct from volume/source advisories).
	foreach ( sa_gate_content_hygiene_issues( $content ) as $issue ) {
		$missing[] = $issue;
	}

	return $missing;
}

/**
 * Find content-hygiene errors that must be fixed before publishing an entity.
 *
 * The transparency markers [نیازمند بررسی] and [منبع لازم] are deliberately not
 * treated as unresolved placeholders: they are rendered visibly for readers.
 *
 * @param string $content Stored editor HTML.
 * @return string[]
 */
function sa_gate_content_hygiene_issues( $content ) {
	$content = (string) $content;
	if ( '' === trim( $content ) ) {
		return array();
	}

	// Ignore comments and non-rendered markup so hidden notes do not trip the gate.
	$html = preg_replace( '/<!--.*?-->/s', ' ', $content );
	$html = preg_replace( '#<(script|style|noscript)\b[^>]*>.*?</\1\s*>#isu', ' ', $html );
	$html = is_string( $html ) ? $html : $content;
	$checks = function_exists( 'sa_content_hygiene_checks' )
		? (array) sa_content_hygiene_checks()
		: array( 'body_h1', 'unresolved_editorial_placeholder', 'empty_or_unlabelled_anchor' );
	$issues = array();

	if ( in_array( 'body_h1', $checks, true ) && preg_match( '/<h1(?:\s|>)/iu', $html ) ) {
		$issues[] = 'بهداشت محتوا: تیتر H1 در بدنهٔ ویرایشگر وجود دارد؛ H1 صفحه از قالب می‌آید';
	}

	$visible = html_entity_decode( strip_tags( $html ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	if ( in_array( 'unresolved_editorial_placeholder', $checks, true ) ) {
		$patterns = array(
			'/\b(?:TODO|FIXME|TBD|PLACEHOLDER|INSERT[_ -]?HERE|LIPSUM)\b/iu',
			'/\{\{[^{}]{1,120}\}\}/u',
			'/(?:برای انتشار نهایی|یادداشت برای نویسنده|یادداشت ویراستاری|این بخش را تکمیل کنید)/u',
			'/«\s*»/u',
		);
		foreach ( $patterns as $pattern ) {
			if ( preg_match( $pattern, $visible ) ) {
				$issues[] = 'بهداشت محتوا: یادداشت تحریریه یا جای‌نگهدار حل‌نشده در متن دیده شد';
				break;
			}
		}
	}

	if ( in_array( 'empty_or_unlabelled_anchor', $checks, true ) ) {
		$empty_anchors = 0;
		if ( preg_match_all( '/<a\b([^>]*)>(.*?)<\/a\s*>/isu', $html, $anchors, PREG_SET_ORDER ) ) {
			foreach ( $anchors as $anchor ) {
				$attributes = $anchor[1];
				if ( ! preg_match( '/\bhref\s*=/iu', $attributes ) ) {
					continue;
				}

				$has_label = false;
				if ( preg_match_all( '/\b(?:aria-label|title)\s*=\s*(["\x27])(.*?)\1/isu', $attributes, $attribute_labels, PREG_SET_ORDER ) ) {
					foreach ( $attribute_labels as $label ) {
						$label_text = html_entity_decode( $label[2], ENT_QUOTES | ENT_HTML5, 'UTF-8' );
						$label_text = preg_replace( '/[\s\p{Z}\x{200B}-\x{200F}\x{FEFF}]+/u', '', $label_text );
						if ( is_string( $label_text ) && '' !== $label_text ) {
							$has_label = true;
							break;
						}
					}
				}

				$inner = $anchor[2];
				if ( ! $has_label && preg_match_all( '/<img\b[^>]*\balt\s*=\s*(["\x27])(.*?)\1/isu', $inner, $alt_matches, PREG_SET_ORDER ) ) {
					foreach ( $alt_matches as $alt ) {
						$alt_text = html_entity_decode( $alt[2], ENT_QUOTES | ENT_HTML5, 'UTF-8' );
						$alt_text = preg_replace( '/[\s\p{Z}\x{200B}-\x{200F}\x{FEFF}]+/u', '', $alt_text );
						if ( is_string( $alt_text ) && '' !== $alt_text ) {
							$has_label = true;
							break;
						}
					}
				}

				$text = html_entity_decode( strip_tags( $inner ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
				$text = preg_replace( '/[\s\p{Z}\x{200B}-\x{200F}\x{FEFF}]+/u', '', $text );
				if ( ! $has_label && ( ! is_string( $text ) || '' === $text ) ) {
					++$empty_anchors;
				}
			}
		}
		if ( $empty_anchors > 0 ) {
			$issues[] = 'بهداشت محتوا: ' . sa_fa_digits( $empty_anchors ) . ' پیوند بدون نام دسترس‌پذیر';
		}
	}

	return $issues;
}

/**
 * Count links to this site inside HTML content (absolute to home_url or root-relative).
 *
 * @param string $content HTML.
 * @return int
 */
function sa_count_internal_links( $content ) {
	if ( '' === trim( (string) $content ) ) {
		return 0;
	}
	$host = wp_parse_url( home_url(), PHP_URL_HOST );
	$n    = 0;
	if ( preg_match_all( '/<a\s[^>]*href=["\']([^"\']+)["\']/iu', $content, $m ) ) {
		foreach ( $m[1] as $href ) {
			$href = trim( $href );
			if ( '' === $href || '#' === $href[0] ) {
				continue;
			}
			if ( '/' === $href[0] && ( ! isset( $href[1] ) || '/' !== $href[1] ) ) {
				$n++;
				continue;
			}
			$h = wp_parse_url( $href, PHP_URL_HOST );
			if ( $h && strcasecmp( $h, $host ) === 0 ) {
				$n++;
			}
		}
	}
	return $n;
}

/**
 * v1.1 — non-blocking warnings: uncertainty markers and stale verification date.
 *
 * @param int        $post_id Post ID.
 * @param string     $type    CPT.
 * @param array|null $form    Submitted form or null.
 * @return string[]
 */
function sa_gate_warnings( $post_id, $type, $form = null ) {
	$warn = array();
	$get  = function ( $key ) use ( $post_id, $form ) {
		if ( null !== $form ) {
			return isset( $form[ $key ] ) ? $form[ $key ] : '';
		}
		return get_post_meta( $post_id, $key, true );
	};
	$content = null !== $form && isset( $form['post_content'] ) ? (string) $form['post_content'] : (string) get_post_field( 'post_content', $post_id );
	$markers = sa_count_markers( $content );
	if ( null !== $form ) {
		$markers += sa_count_markers( implode( ' ', (array) ( isset( $form['sa_faq_a'] ) ? $form['sa_faq_a'] : array() ) ) );
	} else {
		foreach ( sa_get_faq( $post_id ) as $row ) {
			$markers += sa_count_markers( $row['a'] );
		}
	}
	if ( $markers > 0 ) {
		$warn[] = sa_fa_digits( $markers ) . ' برچسب «نیازمند بررسی / منبع لازم» در متن — برای خواننده نمایش داده می‌شود';
	}
	if ( 'attraction' === $type ) {
		$v = (string) $get( 'sa_last_verified_date' );
		if ( '' === $v ) {
			$warn[] = 'تاریخ آخرین راستی‌آزمایی ثبت نشده است';
		} elseif ( strtotime( $v ) && ( time() - strtotime( $v ) ) > sa_stale_after_days() * DAY_IN_SECONDS ) {
			$warn[] = 'راستی‌آزمایی ساعات/قیمت/دسترسی قدیمی‌تر از ' . sa_fa_digits( sa_stale_after_days() ) . ' روز است — نیازمند بازبینی';
		}
	}
	return $warn;
}

/**
 * Gate mode.
 *
 * v2.12.7 — the default is 'soft' (advisory): the owner's approval is the only
 * publish condition, Level 7 findings are reminders. 'hard' must be chosen
 * explicitly in the Customizer («قوانین انتشار»).
 *
 * @return string hard|soft
 */
function sa_gate_mode() {
	$mode = get_theme_mod( 'sa_gate_mode', 'soft' );

	/**
	 * Final gate mode.
	 *
	 * @param string $mode 'soft' (advisory, default) or 'hard' (demote to draft).
	 */
	$mode = apply_filters( 'sa_gate_mode', 'hard' === $mode ? 'hard' : 'soft' );

	return 'hard' === $mode ? 'hard' : 'soft';
}

/**
 * v2.12.7 — Is the gate advisory (reminders only, nothing blocks publishing)?
 *
 * @return bool
 */
function sa_gate_is_advisory() {
	return 'soft' === sa_gate_mode();
}

/**
 * v2.12.7 — Apply the publishing policy to an evaluated post.
 *
 * In advisory mode every blocker becomes a reminder so the UI (badge, side box,
 * notices, ready-articles tool) never presents a «مانع انتشار» that does not exist.
 *
 * @param string[] $blocking Blockers from sa_gate_split().
 * @param string[] $warnings Reminders.
 * @return array{0:string[],1:string[]} [blocking, warnings]
 */
function sa_gate_apply_policy( $blocking, $warnings ) {
	$blocking = array_values( (array) $blocking );
	$warnings = array_values( (array) $warnings );
	if ( $blocking && sa_gate_is_advisory() ) {
		$warnings = array_merge( $blocking, $warnings );
		$blocking = array();
	}
	return array( $blocking, $warnings );
}

/**
 * v2.12.7 — Full reminder list for a stored post (used by admin tools).
 *
 * @param int $post_id Post ID.
 * @return array{blocking:string[],warnings:string[]}
 */
function sa_gate_evaluate( $post_id ) {
	$post_id = (int) $post_id;
	$type    = (string) get_post_type( $post_id );
	if ( ! $post_id || ! sa_is_entity( $type ) ) {
		return array(
			'blocking' => array(),
			'warnings' => array(),
		);
	}
	$missing = sa_gate_missing( $post_id, $type, null );
	list( $blocking, $advisory ) = sa_gate_split( $missing );
	$warnings = array_merge( sa_gate_warnings( $post_id, $type, null ), $advisory );
	list( $blocking, $warnings ) = sa_gate_apply_policy( $blocking, $warnings );

	// صفحهٔ منتشرشده هرگز پایین نمی‌آید (v2.11.42)؛ پس برای آن هم «مانع» معنا ندارد.
	if ( $blocking && 'publish' === (string) get_post_status( $post_id ) && (bool) apply_filters( 'sa_gate_protect_published', true ) ) {
		$warnings = array_merge( $blocking, $warnings );
		$blocking = array();
	}

	return array(
		'blocking' => $blocking,
		'warnings' => $warnings,
	);
}

/**
 * v2.1.0 — تفکیک «مانع انتشار» از «هشدار».
 *
 * نسخه‌ی قبل هر کمبودی را مانع انتشار می‌دانست. چون حداقل لینک داخلیِ «استان»
 * ۲۰ بود و یک استان تا ساخته‌شدن صفحه‌های شهرستانش به ۲۰ لینک نمی‌رسد،
 * ۲۷ استانِ نوشته‌شده (~۱۵۱٬۰۰۰ واژه) در draft قفل شده بودند و سایت هیچ
 * بازخوردی از موتور جست‌وجو نمی‌گرفت.
 *
 * قاعده‌ی تازه: فقط چیزی مانع انتشار است که یک نویسنده بتواند همین حالا و
 * تنها روی همین صفحه درستش کند — تصویر شاخص، فیلدهای سئو، رابطه‌ی والد و
 * طبقه‌بندی اصلی. تعداد FAQ، تعداد لینک داخلی و مختصات به بازخورد یا به
 * صفحه‌های دیگر وابسته‌اند، پس هشدار می‌شوند نه قفل.
 *
 * @param string[] $missing فهرست کمبودها از sa_gate_missing().
 * @return array{0:string[],1:string[]} [مانع‌ها، هشدارها]
 */
function sa_gate_split( $missing ) {
	$advisory_re = '/^(سوالات متداول|لینک داخلی|مختصات)/u';
	$blocking    = array();
	$advisory    = array();
	foreach ( (array) $missing as $row ) {
		$row = (string) $row;
		if ( preg_match( $advisory_re, $row ) ) {
			$advisory[] = $row . ' — مانع انتشار نیست';
			continue;
		}
		$blocking[] = $row;
	}

	/**
	 * فهرست نهایی مانع‌های انتشار.
	 *
	 * برای انتشار بی‌قیدوشرط: add_filter( 'sa_gate_blocking', '__return_empty_array' );
	 *
	 * @param string[] $blocking مانع‌ها.
	 * @param string[] $missing  همه‌ی کمبودها.
	 */
	$blocking = (array) apply_filters( 'sa_gate_blocking', $blocking, $missing );

	return array( $blocking, $advisory );
}

/**
 * Enforce on publish (edit screen only — quick edit / REST / CLI evaluate stored meta).
 *
 * @param array $data    Slashed data.
 * @param array $postarr Post array.
 * @return array
 */
function sa_gate_filter( $data, $postarr ) {
	if ( 'publish' !== $data['post_status'] || ! sa_is_entity( $data['post_type'] ) ) {
		return $data;
	}
	$post_id = isset( $postarr['ID'] ) ? (int) $postarr['ID'] : 0;

	// Form submission from the edit screen?
	$from_form = isset( $_POST['sa_meta_nonce'] ) && wp_verify_nonce( sanitize_key( $_POST['sa_meta_nonce'] ), 'sa_save_meta' ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
	if ( $from_form ) {
		$missing = sa_gate_missing( $post_id, $data['post_type'], wp_unslash( $_POST ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
	} elseif ( $post_id ) {
		$missing = sa_gate_missing( $post_id, $data['post_type'], null );
	} else {
		return $data;
	}

	$warnings = sa_gate_warnings( $post_id, $data['post_type'], $from_form ? wp_unslash( $_POST ) : null ); // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

	// v2.1.0 — کمبودها به دو دسته تقسیم می‌شوند.
	list( $blocking, $advisory ) = sa_gate_split( $missing );
	$warnings = array_merge( $warnings, $advisory );

	/*
	 * v2.12.7 — سیاست انتشار: شرط انتشار فقط تأیید مالک است.
	 * در حالت پیش‌فرض (یادآوری) هیچ‌چیز مانع انتشار نمی‌شود؛ کمبودهای سطح ۷ به
	 * یادآوری تبدیل و روی نوشته ثبت می‌شوند. حالت «سخت‌گیر» فقط با انتخاب صریح
	 * در سفارشی‌ساز فعال می‌شود.
	 */
	list( $blocking, $warnings ) = sa_gate_apply_policy( $blocking, $warnings );

	$user = get_current_user_id();

	/*
	 * v2.11.42 — محافظت از صفحه‌های منتشرشده.
	 *
	 * تا پیش از این، هر بار که مالک یک صفحهٔ زنده را ویرایش می‌کرد و یکی از
	 * شرط‌های دروازه برآورده نمی‌شد، وردپرس آن صفحه را «پیش‌نویس» ذخیره می‌کرد
	 * (نوارِ سرخِ «انتشار نوشته به‌صورت پیش‌نویس ذخیره شد»)؛ یعنی یک صفحهٔ زنده
	 * بی‌سروصدا از سایت بیرون می‌رفت. حالا صفحهٔ منتشرشده هرگز پایین نمی‌آید؛
	 * مانع‌ها به «یادآوری» تبدیل می‌شوند و در متای نوشته ثبت می‌مانند.
	 */
	$current_status = $post_id ? (string) get_post_status( $post_id ) : '';
	$protect        = ( 'publish' === $current_status ) && (bool) apply_filters( 'sa_gate_protect_published', true );
	if ( $protect && $blocking ) {
		$warnings = array_merge( $blocking, $warnings );
		$blocking = array();
	}

	if ( $protect || $blocking || $warnings ) {
		$mode = $protect ? 'protected' : ( $blocking ? 'hard' : 'info' );
		set_transient(
			'sa_gate_' . $user,
			array(
				'post'     => $post_id,
				'missing'  => $blocking,
				'warnings' => $warnings,
				'mode'     => $mode,
			),
			120
		);
		sa_gate_store_report( $post_id, $blocking, $warnings, $mode, $protect );
	}

	if ( $blocking ) {
		$data['post_status'] = 'draft';
	}
	return $data;
}
add_filter( 'wp_insert_post_data', 'sa_gate_filter', 20, 2 );

/**
 * v2.11.42 — ذخیرهٔ ماندگارِ گزارشِ دروازه روی خودِ نوشته.
 *
 * نوارهای پیشخوان موقتی‌اند (۱۲۰ ثانیه و با یک بار دیدن پاک می‌شوند)؛ این متا
 * می‌ماند تا در جعبهٔ کنارِ ویرایشگر همیشه معلوم باشد «چه چیزی مانع انتشار است».
 *
 * @param int      $post_id  شناسهٔ نوشته.
 * @param string[] $blocking مانع‌ها.
 * @param string[] $warnings یادآوری‌ها.
 * @param string   $mode     hard|protected|info.
 * @param bool     $protect  آیا صفحهٔ زنده محافظت شد؟
 * @return void
 */
function sa_gate_store_report( $post_id, $blocking, $warnings, $mode, $protect = false ) {
	if ( ! $post_id || ! sa_is_entity( get_post_type( $post_id ) ) ) {
		return;
	}
	update_post_meta(
		$post_id,
		'_sa_gate_report',
		array(
			'time'     => time(),
			'mode'     => (string) $mode,
			'protect'  => (bool) $protect,
			'blocking' => array_values( array_map( 'strval', (array) $blocking ) ),
			'warnings' => array_values( array_map( 'strval', (array) $warnings ) ),
		)
	);
}

/**
 * v2.11.42 — راهنمای کوتاهِ رفع برای هر مانع.
 *
 * @param string $item متن مانع از sa_gate_missing().
 * @return string راهنمای فارسی (یا رشتهٔ خالی).
 */
function sa_gate_hint( $item ) {
	$item = (string) $item;
	$map  = array(
		'رابطه:'             => 'در جعبهٔ «روابط» انتخاب کنید.',
		'سئو:'               => 'جعبهٔ «سئو» را کامل کنید (عنوان، توضیحات متا، کلیدواژه).',
		'طبقه‌بندی اصلی:'    => 'در جعبهٔ طبقه‌بندی‌ها ترم را انتخاب کنید.',
		'تصویر شاخص'         => 'تصویر شاخص بگذارید؛ برای مقالات آماده دکمهٔ «ساخت کارت تصویر شاخص» را بزنید.',
		'منابع:'             => 'فهرست منابع را کامل کنید؛ هر منبع با نشانیِ https در یک خط.',
		'بهداشت محتوا:'      => 'متن را اصلاح کنید؛ اگر H1 در بدنه است یا عبارت تحریری جامانده، «سرزمین آریان → سلامت محتوا → تعمیر محتوا» آن را اصلاح می‌کند.',
		'مختصات جغرافیایی'   => 'عرض و طول جغرافیایی را پر کنید (مانع نیست، ولی در نقشه لازم است).',
		'لینک داخلی:'        => 'لینک داخلی مفید بیفزایید (مانع نیست).',
	);
	foreach ( $map as $needle => $hint ) {
		if ( 0 === strpos( $item, $needle ) ) {
			return $hint;
		}
	}
	return '';
}

/**
 * v2.11.42 — جعبهٔ «دروازهٔ انتشار» در کنارِ ویرایشگر.
 *
 * @return void
 */
function sa_gate_register_box() {
	$title = sa_gate_is_advisory() ? 'دروازهٔ انتشار — یادآوری‌های سطح ۷' : 'دروازهٔ انتشار — چه چیزی مانع است؟';
	foreach ( sa_entity_types() as $type ) {
		add_meta_box( 'sa_gate_report', $title, 'sa_gate_render_report_box', $type, 'side', 'high' );
	}
}
add_action( 'add_meta_boxes', 'sa_gate_register_box' );

/**
 * v2.11.42 — نمایشِ ماندگارِ مانع‌ها/یادآوری‌ها با راهنمای رفع.
 *
 * @param WP_Post $post نوشته.
 * @return void
 */
function sa_gate_render_report_box( $post ) {
	$stored = get_post_meta( $post->ID, '_sa_gate_report', true );
	$live   = empty( $stored );
	if ( $live ) {
		$type     = (string) get_post_type( $post->ID );
		$missing  = sa_gate_missing( (int) $post->ID, $type, null );
		list( $blocking, $advisory ) = sa_gate_split( $missing );
		$warnings = array_merge( sa_gate_warnings( (int) $post->ID, $type, null ), $advisory );
		$report   = array(
			'time'     => 0,
			'mode'     => $blocking ? 'hard' : 'info',
			'protect'  => 'publish' === get_post_status( $post->ID ),
			'blocking' => $blocking,
			'warnings' => $warnings,
		);
	} else {
		$report = (array) $stored;
	}

	$blocking = isset( $report['blocking'] ) ? (array) $report['blocking'] : array();
	$warnings = isset( $report['warnings'] ) ? (array) $report['warnings'] : array();
	$time     = isset( $report['time'] ) ? (int) $report['time'] : 0;

	// v2.12.7 — در حالت یادآوری، گزارش‌های قدیمیِ ذخیره‌شده هم مانع نشان داده نمی‌شوند.
	list( $blocking, $warnings ) = sa_gate_apply_policy( $blocking, $warnings );

	echo '<div class="sa-box sa-stack">';
	if ( sa_gate_is_advisory() ) {
		echo '<p class="description">شرط انتشار فقط تأیید مالک است؛ موارد زیر یادآوری‌اند و مانع انتشار نیستند.</p>';
	}
	if ( $time ) {
		echo '<p class="description">آخرین بررسی: ' . esc_html( sa_fa_digits( sa_jalali_date( 'j F Y — H:i', $time ) ) ) . '</p>';
	} else {
		echo '<p class="description">ارزیابیِ زندهٔ همین لحظه (هنوز ذخیره‌ای ثبت نشده است).</p>';
	}

	if ( ! $blocking ) {
		echo '<p><strong>مانعی برای انتشار نیست. ✓</strong></p>';
	} else {
		echo '<p style="color:#b32d2e"><strong>' . esc_html( sa_fa_digits( count( $blocking ) ) ) . ' مانع انتشار:</strong></p><ul style="list-style:disc;margin-inline-start:1.2em">';
		foreach ( $blocking as $item ) {
			echo '<li>' . esc_html( $item );
			$hint = sa_gate_hint( $item );
			if ( '' !== $hint ) {
				echo '<br /><span class="description">' . esc_html( $hint ) . '</span>';
			}
			echo '</li>';
		}
		echo '</ul>';
	}

	if ( $warnings ) {
		echo '<p><strong>یادآوری‌ها (' . esc_html( sa_fa_digits( count( $warnings ) ) ) . '):</strong></p><ul style="list-style:disc;margin-inline-start:1.2em">';
		foreach ( $warnings as $item ) {
			echo '<li>' . esc_html( $item );
			$hint = sa_gate_hint( $item );
			if ( '' !== $hint ) {
				echo '<br /><span class="description">' . esc_html( $hint ) . '</span>';
			}
			echo '</li>';
		}
		echo '</ul>';
	}

	if ( ! empty( $report['protect'] ) ) {
		echo '<p class="description">این صفحه منتشر شده است؛ دروازه هیچ‌وقت صفحهٔ زنده را به پیش‌نویس برنمی‌گرداند.</p>';
	}
	echo '</div>';
}

/**
 * Keep the message visible after redirect.
 *
 * @param string $location Redirect URL.
 * @return string
 */
function sa_gate_redirect( $location ) {
	if ( get_transient( 'sa_gate_' . get_current_user_id() ) ) {
		$location = add_query_arg( 'sa_gate', '1', remove_query_arg( 'message', $location ) );
	}
	return $location;
}
add_filter( 'redirect_post_location', 'sa_gate_redirect' );

/**
 * Admin notice.
 */
function sa_gate_notice() {
	$data = get_transient( 'sa_gate_' . get_current_user_id() );
	if ( ! $data ) {
		return;
	}
	delete_transient( 'sa_gate_' . get_current_user_id() );
	$warnings = isset( $data['warnings'] ) ? (array) $data['warnings'] : array();
	$mode     = isset( $data['mode'] ) ? (string) $data['mode'] : 'info';
	if ( ! empty( $data['missing'] ) || ( 'protected' === $mode && $warnings ) ) {
		if ( 'protected' === $mode ) {
			$class = 'notice-warning';
			$title = 'منتشر ماند و از سایت بیرون نرفت؛ اما این موارد را تکمیل کنید:';
		} else {
			$class = 'hard' === $mode ? 'notice-error' : 'notice-warning';
			$title = 'hard' === $mode ? 'انتشار متوقف شد و نوشته به‌صورت پیش‌نویس ذخیره شد.' : 'با تأیید شما منتشر شد؛ این یادآوری‌های سطح ۷ مانع انتشار نیستند، اما بهتر است تکمیل شوند:';
		}
		echo '<div class="notice ' . esc_attr( $class ) . ' is-dismissible"><p><strong>';
		echo esc_html( $title );
		echo '</strong> (دروازه‌ی انتشار — مدل داده سطح ۷)</p><ul style="list-style:disc;margin-inline-start:1.5em">';
		foreach ( array_merge( (array) $data['missing'], $warnings ) as $m ) {
			echo '<li>' . esc_html( $m );
			$hint = sa_gate_hint( $m );
			if ( '' !== $hint ) {
				echo ' <span class="description">' . esc_html( $hint ) . '</span>';
			}
			echo '</li>';
		}
		echo '</ul></div>';
		return;
	}
	if ( $warnings ) {
		echo '<div class="notice notice-info is-dismissible"><p><strong>یادآوری‌های راستی‌آزمایی:</strong></p><ul style="list-style:disc;margin-inline-start:1.5em">';
		foreach ( $warnings as $w ) {
			echo '<li>' . esc_html( $w );
			$hint = sa_gate_hint( $w );
			if ( '' !== $hint ) {
				echo ' <span class="description">' . esc_html( $hint ) . '</span>';
			}
			echo '</li>';
		}
		echo '</ul></div>';
	}
}
add_action( 'admin_notices', 'sa_gate_notice' );

/**
 * Status badge for admin columns / dashboard.
 *
 * @param int $post_id Post ID.
 * @return string HTML
 */
function sa_gate_badge( $post_id ) {
	$type     = get_post_type( $post_id );
	$missing  = sa_gate_missing( $post_id, $type, null );
	$warnings = sa_gate_warnings( $post_id, $type, null );

	// v2.1.0 — فقط مانع‌ها قرمزند؛ بقیه «قابل بهبود».
	list( $blocking, $advisory ) = sa_gate_split( $missing );
	$warnings = array_merge( $warnings, $advisory );

	// v2.12.7 — در حالت یادآوری هیچ مانعی وجود ندارد؛ همه‌چیز «قابل بهبود» است.
	list( $blocking, $warnings ) = sa_gate_apply_policy( $blocking, $warnings );

	$extra = $warnings ? ' <span class="sa-badge sa-badge--stale" title="' . esc_attr( implode( ' · ', $warnings ) ) . '">' . esc_html( sa_fa_digits( count( $warnings ) ) ) . ' یادآوری</span>' : '';

	/*
	 * v2.11.42 — نشانِ صفحهٔ منتشرشده.
	 *
	 * پیش از این، صفحهٔ منتشرشده‌ای که شرایطِ سطح ۷ را نداشت هم برچسبِ سرخِ
	 * «مانع انتشار» می‌گرفت؛ مالک از فهرست چنین برداشت می‌کرد که صفحه منتشر
	 * نشده است. حالا وضعیتِ واقعی نوشته صریح نوشته می‌شود و تعدادِ مواردِ
	 * باقی‌مانده (که خودِ دروازه هم فهرست می‌کند) کنارش می‌آید.
	 */
	if ( 'publish' === (string) get_post_status( $post_id ) ) {
		if ( empty( $blocking ) ) {
			return '<span class="sa-badge sa-badge--ok" title="منتشرشده و از نظرِ دروازهٔ سطح ۷ کامل است">منتشرشده ✓</span>' . $extra;
		}
		return '<span class="sa-badge sa-badge--stale" title="' . esc_attr( implode( ' · ', $blocking ) ) . '">منتشرشده · ' . esc_html( sa_fa_digits( count( $blocking ) ) ) . ' مورد برای تکمیل</span>' . $extra;
	}

	if ( empty( $blocking ) ) {
		return '<span class="sa-badge sa-badge--ok" title="آماده‌ی انتشار است">قابل انتشار ✓</span>' . $extra;
	}
	return '<span class="sa-badge sa-badge--warn" title="' . esc_attr( implode( ' · ', $blocking ) ) . '">' . esc_html( sa_fa_digits( count( $blocking ) ) ) . ' مانع انتشار</span>' . $extra;
}
