# Article-image attributions

This document records eleven WebP photographs bundled with the child theme and sixteen Wikimedia photographs that the ready-article importer will copy into the local WordPress media library when the relevant drafts are imported. The importer records each source URL; published pages therefore do not hotlink Wikimedia. The eight bundled article-image WebPs were resized when needed, adjusted with Pillow (color ×1.07, contrast ×1.06, sharpness ×1.12), and saved as WebP, quality 82, method 6. The three Sar Agha Seyed derivatives were converted from Commons JPEGs to WebP (quality 86, method 6) without cropping, upscaling, or changing their pixel dimensions; the Mehr News watermark is retained. Every image remains under its source media license, and CC BY-SA derivatives retain the applicable ShareAlike license. These media files are not relicensed under the theme's software license.

| Bundled WebP | Credit and source | License |
|---|---|---|
| `persepolis/01-columns.webp` | ArminAmirian, [Takht-e Jamshid Fars Iran 17](https://commons.wikimedia.org/wiki/File:Takht-e_Jamshid_Fars_Iran_17.jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) |
| `persepolis/03-panorama.webp` | Diego Delso, [Persépolis, Irán, 2016-09-24, DD 56](https://commons.wikimedia.org/wiki/File:Pers%C3%A9polis,_Ir%C3%A1n,_2016-09-24,_DD_56.jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) |
| `naqsh-e-jahan/01-square-panorama.webp` | Original photograph: Zahra gharaati; panorama derivative/retouch: Aristeas, [Panorama of Naqsh-i Jahan Square at blue hour](https://commons.wikimedia.org/wiki/File:Panorama_of_Naqsh-i_Jahan_Square,_Isfahan_at_blue_hour_(2019,_edited).jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) |
| `naqsh-e-jahan/02-shah-mosque-hall.webp` | Diego Delso, [Shah Mosque, DD 68–70 HDR](https://commons.wikimedia.org/wiki/File:Mezquita_Shah,_Isfah%C3%A1n,_Ir%C3%A1n,_2016-09-20,_DD_68-70_HDR.jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) |
| `naqsh-e-jahan/03-portal.webp` | Diego Delso, [Shah Mosque, DD 62](https://commons.wikimedia.org/wiki/File:Mezquita_Shah,_Isfah%C3%A1n,_Ir%C3%A1n,_2016-09-20,_DD_62.jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) |
| `shahdad-kaluts/01-yardangs.webp` | yeowatzup, [Kaluts, Iran (5071922915)](https://commons.wikimedia.org/wiki/File:Kaluts,_Iran_(5071922915).jpg) | [CC BY 2.0](https://creativecommons.org/licenses/by/2.0/) |
| `shahdad-kaluts/02-lut-yardangs.webp` | Hadi Karimi, [Lut Desert Yardangs](https://commons.wikimedia.org/wiki/File:Lut_Desert_Yardangs_by_Hadi_Karimi.jpg) | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/) |
| `shahdad-kaluts/03-kaluts-sunset.webp` | Ninara, [Kaluts, Lut Desert, Kerman Province, Iran (28898445158)](https://commons.wikimedia.org/wiki/File:Kaluts,_Lut_Desert,_Kerman_Province,_Iran_(28898445158).jpg) | [CC BY 2.0](https://creativecommons.org/licenses/by/2.0/) |
| `sar-agha-seyed-village/01-village-panorama.webp` | Jan Strmiska, [Sar Aqa Seyyed, village in Iran, Zagros Mountains 01](https://commons.wikimedia.org/wiki/File:Sar_Aqa_Seyyed,_village_in_Iran,_Zagros_Mountains_01.jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) |
| `sar-agha-seyed-village/02-terraced-houses.webp` | Bakhtiari Ashayer, [Sar Agha Seyed Village](https://commons.wikimedia.org/wiki/File:Sar_Agha_Seyed_Village.jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) |
| `sar-agha-seyed-village/03-evening-village.webp` | Farhad Safari; attribution to Mehr News Agency, [Sar Aqa Seyyed 20171028 22](https://commons.wikimedia.org/wiki/File:Sar_Aqa_Seyyed_20171028_22.jpg), [original Mehr News photo page](https://www.mehrnews.com/photo/4127420/) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) (watermark retained) |

The Sar Agha Seyed, Tabas, Tang-e-Sayad, Azgen, Fin Garden, Masouleh, Persepolis, Naqsh-e-Jahan, and Shahdad gallery entries include the creator, Commons source page, and license link in their attribution records and visible captions. Bundled WebP captions include an image-processing note; Wikimedia images imported into a draft include a local-import note. The three Azgen photos retain the original Mehr News Agency credit.

## Wikimedia images copied into WordPress on article import

These sixteen images are referenced by their Wikimedia URLs in `data/ready-articles.php`. The importer copies each one to the local media library once and stores its source URL; they are not served from an external hotlink on the published page. The UNESCO images document the combined Tang-e-Sayad and Sabzkuh biosphere reserve; their captions explicitly avoid presenting them as a precise view inside the national park. The Persepolis griffin detail, Fin Garden, and Masouleh entries use 1280-pixel Wikimedia-generated thumbnails where the original files are large; the Azgen originals are 1000×667 pixels.

| Article / gallery item | Credit and source | License |
|---|---|---|
| Tabas / `golshan` | Alichenir, [Golshan Garden - Tabas 2011](https://commons.wikimedia.org/wiki/File:Golshan_Garden_-_Tabas_2011.jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) |
| Tabas / `cliffs` | Mahdi Kalhor, [Cliffs in Tabas in Iran](https://commons.wikimedia.org/wiki/File:Cliffs_in_Tabas_in_Iran.jpg) | [CC BY 3.0](https://creativecommons.org/licenses/by/3.0/) |
| Tabas / `nayband` | مهدی مخلصیان (Mahdi Mokhlisian), [Nayband](https://commons.wikimedia.org/wiki/File:Nayband.JPG) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) |
| Tang-e-Sayad / `tang` | Mohammad abbasi 8, [2 Tang sayyad](https://commons.wikimedia.org/wiki/File:2_Tang_sayyad.jpg) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| Tang-e-Sayad / `biosphere_one` | UNESCO, [Mab2015 iran tang e sayad01](https://commons.wikimedia.org/wiki/File:Mab2015_iran_tang_e_sayad01.jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) |
| Tang-e-Sayad / `biosphere_two` | UNESCO, [Mab2015 iran tang e sayad02](https://commons.wikimedia.org/wiki/File:Mab2015_iran_tang_e_sayad02.jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) |
| Persepolis / `griffins` | Hansueli Krapf, [Persepolis 24.11.2009 11-18-45](https://commons.wikimedia.org/wiki/File:Persepolis_24.11.2009_11-18-45.jpg) | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/) |
| Azgen / `plain` | Behnam Yousefi / Mehr News Agency, [Ezgen wetland 20190513 01](https://commons.wikimedia.org/wiki/File:Ezgen_wetland_20190513_01.jpg) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |
| Azgen / `water` | Behnam Yousefi / Mehr News Agency, [Ezgen wetland 20190513 05](https://commons.wikimedia.org/wiki/File:Ezgen_wetland_20190513_05.jpg) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |
| Azgen / `green` | Behnam Yousefi / Mehr News Agency, [Ezgen wetland 20190513 09](https://commons.wikimedia.org/wiki/File:Ezgen_wetland_20190513_09.jpg) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |
| Fin Garden / `central_pavilion` | Amir Pashaei, [Fin Garden, Kashan, Iran](https://commons.wikimedia.org/wiki/File:Fin_Garden,_Kashan,_Iran.jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) |
| Fin Garden / `arches` | Mohannad.m.nazari, [Arches in Fin Garden, Kashan, Iran, October 2017](https://commons.wikimedia.org/wiki/File:Arches_in_Fin_Garden,_Kashan,_Iran,_October_2017.jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) |
| Fin Garden / `hammam` | Amir Pashaei, [Fin bathroom in Fin garden, Kashan, Iran](https://commons.wikimedia.org/wiki/File:Fin_bathroom_in_Fin_garden,_Kashan,_Iran.jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) |
| Masouleh / `panorama` | Far-gh, [MasulehView.JPG](https://commons.wikimedia.org/wiki/File:MasulehView.JPG) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) |
| Masouleh / `rooftop` | Blondinrikard Fröberg (Göteborg, Sweden), [Masouleh, rooftop village (42207998385)](https://commons.wikimedia.org/wiki/File:Masouleh,_rooftop_village_(42207998385).jpg) | [CC BY 2.0](https://creativecommons.org/licenses/by/2.0/) |
| Masouleh / `approach` | Mardetanha, [In the way of masuleh](https://commons.wikimedia.org/wiki/File:In_the_way_of_masuleh.JPG) | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/) |

## AI-generated drone-view illustrations (v2.20.0 onward)

The illustrated 16:9 covers of the newly written featured-site articles live in
`assets/img/articles/<slug>/01-drone-view.webp`. They are **AI-generated images,
not third-party photographs**: each is an elevated aerial (drone-like) view of the
site, produced with vivid, lively colours, then cropped to 1080×608, adjusted with
Pillow (`ImageEnhance` colour ×1.10, contrast ×1.04, sharpness ×1.08) and saved as
WebP (quality 82, method 6). A narrow white bar sits on the **right side of the
lower third** of every image and carries the English site name `sarzaminaryan.ir`
with a thin emerald accent on its inner edge.

Because they are synthesised rather than photographed, they are **not** evidence of
the current condition of a monument: they are used as in-article illustrations only
(the featured-image slot of attractions stays disabled, see `inc/featured-images.php`),
and every figure carries a caption that says the view is an AI reconstruction. No
rights from Wikimedia Commons or any other photographer are involved in these files.

| Folder | Article | Note |
|---|---|---|
| `pasargadae/`, `naqsh-e-rostam/`, `eram-garden/`, `vakil-complex/`, `shah-cheragh/` | Fars group 1 | AI drone-view, watermarked `sarzaminaryan.ir` |
| `bishapur/`, `margoon-falls/`, `si-o-se-pol/`, `khaju-bridge/`, `vank-cathedral/` | Fars/Isfahan group 2 | AI drone-view, watermarked `sarzaminaryan.ir` |
